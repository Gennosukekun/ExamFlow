ExamFlow Italia - Android + Hatchable Auth

Questa build carica direttamente:
https://examflow-4zkm.hatchable.site/mobile.html

Vantaggi:
- login reale via email + codice monouso Hatchable
- sessione persistente tramite cookie WebView
- progressi sincronizzati nel cloud per account
- quiz AI disponibili solo agli utenti autenticati
- aggiornamenti grafici/funzionali sul server senza dover ricompilare l'APK ogni volta

Il progetto genera un APK debug installabile tramite:
gradle assembleDebug
