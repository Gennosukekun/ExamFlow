ExamFlow Italia Modern v2.0

Nuova interfaccia mobile con schermate separate:
- Home
- Piano
- Quiz AI
- Ripasso
- Statistiche
- Profilo

Il progetto è pensato per essere compilato con lo stesso workflow GitHub Actions già usato in precedenza.
Per sostituire la vecchia versione, carica questo ZIP nel repository rinominandolo:
ExamFlow_Italia_Android_Project.zip
