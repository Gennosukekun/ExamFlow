ExamFlow Italia - progetto Android

Questa versione è indipendente da Hatchable e carica ExamFlow direttamente dentro l'app.
Le funzioni di piano, statistiche, errori, streak e recupero funzionano localmente.
Per i quiz AI, nell'app premi "Chiave Gemini" e inserisci una chiave API Gemini personale.
La chiave resta salvata sul dispositivo e non è inclusa nel progetto.

Per generare l'APK:
1. Apri questa cartella con Android Studio.
2. Attendi il completamento della sincronizzazione Gradle.
3. Build > Build APK(s).
4. L'APK sarà generato nella cartella app/build/outputs/apk/debug/.

Nessun pagamento o servizio a pagamento è stato attivato.
