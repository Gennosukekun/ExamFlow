const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const K={plan:"ef_plan",errors:"ef_errors",stats:"ef_stats",streak:"ef_streak",theme:"ef_theme"};
let plan=load(K.plan,null), errors=load(K.errors,[]), stats=load(K.stats,[]), streak=load(K.streak,{days:[],xp:0});
let currentScreen="home", quizMode="practice", currentQuiz=null;

function load(k,d){try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}}
function save(k,v){localStorage.setItem(k,JSON.stringify(v))}
function toast(t){const el=$("#toast");el.textContent=t;el.classList.remove("hidden");setTimeout(()=>el.classList.add("hidden"),2200)}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function d0(){let d=new Date();d.setHours(12,0,0,0);return d}
function dateOnly(s){return new Date(s+"T12:00:00")}
function iso(d){return d.toISOString().slice(0,10)}
function addDays(d,n){let x=new Date(d);x.setDate(x.getDate()+n);return x}
function localDay(d=new Date()){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`}

const dayLabels=["Dom","Lun","Mar","Mer","Gio","Ven","Sab"];
let selectedDays=new Set([1,2,3,4,5]);
dayLabels.forEach((x,i)=>{const b=document.createElement("button");b.className="day-pill"+(selectedDays.has(i)?" active":"");b.textContent=x;b.onclick=()=>{selectedDays.has(i)?selectedDays.delete(i):selectedDays.add(i);b.classList.toggle("active")};$("#days").appendChild(b)});

function go(screen){
  if(screen==="stats"){}
  currentScreen=screen;
  $$(".screen").forEach(x=>x.classList.toggle("active",x.dataset.screen===screen));
  $$(".nav").forEach(x=>x.classList.toggle("active",x.dataset.goto===screen));
  const sub={home:"Il tuo piano verso l’esame",plan:"Organizza ogni giornata",quiz:"Allenati con l’AI",review:"Trasforma gli errori in punti forti",stats:"Misura i tuoi progressi",profile:"Personalizza ExamFlow"}[screen];
  $("#topSubtitle").textContent=sub||"ExamFlow";
  window.scrollTo({top:0,behavior:"smooth"});
  render();
}
$$("[data-goto]").forEach(b=>b.onclick=()=>go(b.dataset.goto));
window.examflowBack=()=>{if(currentScreen!=="home"){go("home");return true}return false};

function applyTheme(){
  const dark=load(K.theme,false); document.body.classList.toggle("dark",dark);
}
function toggleTheme(){save(K.theme,!load(K.theme,false));applyTheme()}
$("#themeBtn").onclick=toggleTheme; $("#themeSetting").onclick=toggleTheme; applyTheme();

function buildPlan(){
  const subject=$("#subject").value.trim(), examDate=$("#examDate").value, total=+$("#totalUnits").value;
  if(!subject||!examDate||!total)return toast("Completa materia, data e quantità totale.");
  if(!selectedDays.size)return toast("Seleziona almeno un giorno.");
  const exam=dateOnly(examDate), today=d0(); if(exam<=today)return toast("La data dell’esame deve essere futura.");
  const available=[]; for(let d=new Date(today);d<exam;d=addDays(d,1)) if(selectedDays.has(d.getDay())) available.push(new Date(d));
  if(!available.length)return toast("Non ci sono giorni disponibili.");
  const reviewDays=Math.min(+$("#reviewDays").value||0,Math.max(0,available.length-1));
  const studyDays=available.slice(0,available.length-reviewDays), review=available.slice(available.length-reviewDays);
  if(!studyDays.length)return toast("Riduci i giorni finali di ripasso.");
  const topics=$("#syllabus").value.split(/\n|,/).map(x=>x.trim()).filter(Boolean);
  const base=Math.floor(total/studyDays.length), rem=total%studyDays.length; let cursor=1;
  const schedule=studyDays.map((d,i)=>{const amount=base+(i<rem?1:0),from=cursor,to=cursor+amount-1;cursor=to+1;const a=Math.floor(i*topics.length/studyDays.length),b=Math.floor((i+1)*topics.length/studyDays.length);return{id:`s-${i}-${iso(d)}`,date:iso(d),type:"study",amount,from,to,topics:topics.slice(a,Math.max(a+1,b)),done:false}});
  review.forEach((d,i)=>schedule.push({id:`r-${i}-${iso(d)}`,date:iso(d),type:"review",done:false}));
  plan={subject,examDate,totalUnits:total,unitType:$("#unitType").value,hoursPerDay:+$("#hoursPerDay").value,reviewDays,selectedDays:[...selectedDays],topics,schedule};
  save(K.plan,plan); toast("Piano creato."); render(); go("home");
}
$("#createPlanBtn").onclick=buildPlan;
$("#newPlanBtn").onclick=()=>{if(plan&&!confirm("Creare un nuovo piano?"))return;plan=null;save(K.plan,null);render()};
$("#printBtn").onclick=()=>window.print();

function progressPct(){
  if(!plan?.schedule?.length)return 0;
  return Math.round(100*plan.schedule.filter(x=>x.done).length/plan.schedule.length);
}
function daysLeft(){return plan?Math.max(0,Math.ceil((dateOnly(plan.examDate)-d0())/86400000)):0}
function streakCount(){
  let n=0,d=new Date();for(;;){if((streak.days||[]).includes(localDay(d))){n++;d.setDate(d.getDate()-1)}else break}return n
}
function readiness(){
  const recent=stats.slice(0,10),avg=recent.length?recent.reduce((a,b)=>a+b.pct,0)/recent.length:0,p=progressPct(),vol=Math.min(100,recent.length*10);
  return Math.round(avg*.65+p*.25+vol*.10)
}
function renderHome(){
  $("#homeSubject").textContent=plan?.subject||"Nessun esame attivo";
  $("#homeExamMeta").textContent=plan?`${dateOnly(plan.examDate).toLocaleDateString("it-IT")} · ${daysLeft()} giorni rimasti`:"Crea un piano per iniziare.";
  const p=progressPct();$("#ringValue").textContent=p+"%";$("#progressRing").style.setProperty("--p",p);
  $("#daysMetric").textContent=daysLeft();$("#streakMetric").textContent=streakCount();$("#xpMetric").textContent=streak.xp||0;
  const c=$("#todayCard");
  if(!plan){c.className="card empty-state";c.textContent="Crea un piano per vedere l’obiettivo di oggi.";return}
  const t=iso(d0()), x=plan.schedule.find(x=>x.date===t&&!x.done)||plan.schedule.find(x=>x.date>=t&&!x.done);
  if(!x){c.className="card empty-state";c.textContent="Piano completato. Ottimo lavoro.";return}
  const d=dateOnly(x.date);c.className="card";c.innerHTML=`<div class="eyebrow">${d.toLocaleDateString("it-IT",{weekday:"long",day:"numeric",month:"long"})}</div><h3>${x.type==="study"?`Studia ${x.amount} ${esc(plan.unitType)}`:"Giornata di ripasso"}</h3><p class="muted">${x.type==="study"?`${x.from}–${x.to}${x.topics?.length?` · ${x.topics.map(esc).join(", ")}`:""}`:"Concentrati sugli errori e sugli argomenti deboli."}</p><button id="todayStart" class="primary-btn">Inizia ora</button>`;
  $("#todayStart").onclick=()=>{if(x.type==="study"){$("#aiSubject").value=plan.subject;$("#aiTopic").value=x.topics?.join(", ")||`${plan.unitType} ${x.from}-${x.to}`;go("quiz")}else go("review")}
}
function renderPlan(){
  $("#planBuilder").classList.toggle("hidden",!!plan);$("#planActive").classList.toggle("hidden",!plan);
  if(!plan)return;
  const p=progressPct();$("#planSummaryTitle").textContent=plan.subject;$("#planSummaryMeta").textContent=`Esame ${dateOnly(plan.examDate).toLocaleDateString("it-IT")} · ${p}% completato`;$("#planPct").textContent=p+"%";$(".mini-ring").style.setProperty("--p",p);
  const el=$("#schedule");el.innerHTML="";
  plan.schedule.forEach((x,i)=>{const d=dateOnly(x.date),m=d.toLocaleDateString("it-IT",{month:"short"}).replace(".","");const row=document.createElement("div");row.className="timeline-item"+(x.done?" done":"");row.innerHTML=`<div class="date-badge"><div>${d.getDate()}<br><small>${m.toUpperCase()}</small></div></div><div><b>${x.type==="study"?`${x.amount} ${esc(plan.unitType)} · ${x.from}-${x.to}`:"Ripasso finale"}</b><div class="muted tiny">${x.type==="study"?(x.topics?.map(esc).join(" · ")||"Sessione di studio"):"Errori, quiz e simulazione"}</div></div><input type="checkbox" ${x.done?"checked":""}>`;row.querySelector("input").onchange=e=>{plan.schedule[i].done=e.target.checked;save(K.plan,plan);render()};el.appendChild(row)})
}
$("#lateBtn").onclick=()=>{if(!plan)return;const today=iso(d0()),missed=plan.schedule.filter(x=>x.type==="study"&&!x.done&&x.date<today).reduce((s,x)=>s+x.amount,0),future=plan.schedule.filter(x=>x.type==="study"&&!x.done&&x.date>=today);if(!missed)return toast("Non risultano unità arretrate.");if(!future.length)return toast("Nessun giorno futuro disponibile.");const total=future.reduce((s,x)=>s+x.amount,0)+missed,base=Math.floor(total/future.length),rem=total%future.length;let start=plan.schedule.filter(x=>x.type==="study"&&x.done).reduce((s,x)=>s+x.amount,0)+1;plan.schedule=plan.schedule.filter(x=>!(x.type==="study"&&!x.done&&x.date<today));plan.schedule.filter(x=>x.type==="study"&&!x.done).forEach((x,i)=>{x.amount=base+(i<rem?1:0);x.from=start;x.to=start+x.amount-1;start=x.to+1});save(K.plan,plan);render();toast("Piano ricalcolato.")};

$$(".seg").forEach(b=>b.onclick=()=>{$$(".seg").forEach(x=>x.classList.remove("active"));b.classList.add("active");quizMode=b.dataset.mode});
async function nativeGenerateQuiz(payload){
  if(window.AndroidBridge&&typeof window.AndroidBridge.generateQuiz==="function"){
    return await new Promise((resolve,reject)=>{const cb="cb_"+Date.now()+"_"+Math.random().toString(36).slice(2);window.__cbs=window.__cbs||{};window.__cbs[cb]=(ok,data)=>{try{const d=JSON.parse(data);ok?resolve(d):reject(new Error(d.error||"Errore AI"))}catch(e){reject(e)}delete window.__cbs[cb]};window.AndroidBridge.generateQuiz(JSON.stringify(payload),cb)})
  }
  throw new Error("Questa funzione richiede l’app Android.")
}
function nativeCallback(id,ok,data){window.__cbs?.[id]?.(ok,data)}
$("#generateQuizBtn").onclick=async()=>{const subject=$("#aiSubject").value.trim(),topic=$("#aiTopic").value.trim();if(!subject||!topic)return toast("Inserisci materia e argomento.");$("#quizStatus").textContent="Genero il quiz...";$("#generateQuizBtn").disabled=true;try{const d=await nativeGenerateQuiz({subject,topic,difficulty:$("#aiDifficulty").value,count:+$("#aiCount").value});startQuiz(d.questions,{subject,topic})}catch(e){$("#quizStatus").textContent=e.message}finally{$("#generateQuizBtn").disabled=false}};
function startQuiz(qs,meta){currentQuiz={questions:qs,answers:Array(qs.length).fill(null),meta};$("#quizArea").innerHTML="";qs.forEach((q,i)=>{const c=document.createElement("div");c.className="card question";c.innerHTML=`<h3>${i+1}. ${esc(q.question)}</h3><div class="options"></div>`;q.options.forEach((o,j)=>{const b=document.createElement("button");b.className="option";b.textContent=o;b.onclick=()=>answerQuiz(i,j,c,b);c.querySelector(".options").appendChild(b)});$("#quizArea").appendChild(c)});$("#quizStatus").textContent=`${qs.length} domande pronte.`}
function answerQuiz(i,j,c,b){if(currentQuiz.answers[i]!==null)return;const q=currentQuiz.questions[i],ok=j===q.correctIndex;currentQuiz.answers[i]=ok;c.querySelectorAll(".option").forEach((x,k)=>{x.disabled=true;if(k===q.correctIndex)x.classList.add("correct")});if(!ok){b.classList.add("wrong");errors.unshift({q:q.question,a:q.options[q.correctIndex],explanation:q.explanation||"",subject:currentQuiz.meta.subject,topic:currentQuiz.meta.topic,date:new Date().toISOString()});save(K.errors,errors.slice(0,200))}const p=document.createElement("p");p.className="muted";p.textContent=(ok?"Corretto. ":"Da ripassare. ")+(q.explanation||"");c.appendChild(p);if(currentQuiz.answers.every(x=>x!==null))finishQuiz()}
function finishQuiz(){const total=currentQuiz.answers.length,correct=currentQuiz.answers.filter(Boolean).length,pct=Math.round(correct/total*100);stats.unshift({subject:currentQuiz.meta.subject,topic:currentQuiz.meta.topic,correct,total,pct,date:new Date().toISOString()});stats=stats.slice(0,100);save(K.stats,stats);const today=localDay();if(!(streak.days||[]).includes(today)){streak.days=(streak.days||[]).concat(today).slice(-365);streak.xp=(streak.xp||0)+10;save(K.streak,streak)}const r=document.createElement("div");r.className="card quiz-result";r.innerHTML=`<b>${pct}%</b><h3>${pct>=80?"Ottima preparazione":pct>=60?"Buona base":"Da rinforzare"}</h3><p>${correct}/${total} corrette</p>`;$("#quizArea").appendChild(r);render()}
$("#smartReviewBtn").onclick=()=>{if(!errors.length)return toast("Non hai errori da ripassare.");$("#aiSubject").value=errors.find(x=>x.subject)?.subject||"Ripasso";$("#aiTopic").value=[...new Set(errors.slice(0,10).map(x=>x.topic).filter(Boolean))].join(", ")||errors.slice(0,4).map(x=>x.q).join(" · ");go("quiz")};

function renderReview(){
  $("#errorMetric").textContent=errors.length;$("#weakMetric").textContent=new Set(errors.map(x=>x.topic).filter(Boolean)).size;$("#noErrors").classList.toggle("hidden",errors.length>0);const el=$("#errorsList");el.innerHTML="";
  errors.slice(0,50).forEach((e,i)=>{const c=document.createElement("div");c.className="card error-card";c.innerHTML=`<div class="tag">${esc(e.subject||"Ripasso")}</div><b>${esc(e.q)}</b><p>Risposta: ${esc(e.a)}</p>${e.explanation?`<p>${esc(e.explanation)}</p>`:""}<button>Padroneggiato</button>`;c.querySelector("button").onclick=()=>{errors.splice(i,1);save(K.errors,errors);render()};el.appendChild(c)})
}
function renderStats(){
  const recent=stats.slice(0,10),avg=recent.length?Math.round(recent.reduce((a,b)=>a+b.pct,0)/recent.length):0;$("#avgStat").textContent=avg+"%";$("#readyStat").textContent=readiness()+"%";$("#statsStreak").textContent=streakCount();$("#statsXp").textContent=streak.xp||0;$("#statsLevel").textContent=Math.floor((streak.xp||0)/100)+1;
  const ch=$("#chart");ch.innerHTML="";(recent.length?recent.slice().reverse():[0,0,0,0,0]).forEach((x,i)=>{const val=typeof x==="number"?x:x.pct,b=document.createElement("div");b.className="bar";b.style.height=Math.max(4,val)+"%";b.innerHTML=`<small>${val}%</small>`;ch.appendChild(b)})
}
$("#rescueQuick").onclick=()=>{const c=$("#rescueContent");if(!plan){c.innerHTML="<p>Crea prima un piano di studio.</p>"}else{const days=daysLeft(),pending=plan.schedule.filter(x=>!x.done),study=pending.filter(x=>x.type==="study"),daily=study.length?Math.max(1,Math.ceil(study.length/Math.max(1,days-Math.min(3,days)))):0,weak=[...new Set(errors.map(x=>x.topic).filter(Boolean))].slice(0,3);c.innerHTML=`<div class="rescue-step"><b>Tempo</b><p>${days} giorni · ${pending.length} sessioni aperte</p></div><div class="rescue-step"><b>1. Priorità</b><p>${daily} sessioni di studio al giorno.</p></div><div class="rescue-step"><b>2. Verifica</b><p>Un quiz breve dopo ogni blocco.</p></div><div class="rescue-step"><b>3. Errori</b><p>${weak.length?`Concentrati su ${weak.map(esc).join(", ")}.`:"Ripassa gli errori ogni sera."}</p></div><div class="rescue-step"><b>4. Simulazione</b><p>${days<=7?"Una al giorno.":"Una ogni 2–3 giorni."}</p></div>`}$("#rescueSheet").classList.remove("hidden")};
$("#closeRescue").onclick=()=>$("#rescueSheet").classList.add("hidden");
$("#rescueSheet").onclick=e=>{if(e.target===$("#rescueSheet"))$("#rescueSheet").classList.add("hidden")};

$("#geminiKeyBtn").onclick=()=>{if(!window.AndroidBridge)return toast("Disponibile nell’app Android.");const has=window.AndroidBridge.hasGeminiKey();const k=prompt(has?"Sostituisci la chiave Gemini salvata:":"Inserisci la tua chiave API Gemini:");if(k?.trim()){window.AndroidBridge.setGeminiKey(k.trim());toast("Chiave Gemini salvata.")}};
$("#exportBtn").onclick=()=>{const data=JSON.stringify({plan,errors,stats,streak},null,2);prompt("Copia questo backup:",data)};
$("#resetAllBtn").onclick=()=>{if(confirm("Cancellare tutti i dati locali?")){Object.values(K).forEach(k=>localStorage.removeItem(k));plan=null;errors=[];stats=[];streak={days:[],xp:0};render();toast("Dati cancellati.")}};

function render(){renderHome();renderPlan();renderReview();renderStats()}
render();