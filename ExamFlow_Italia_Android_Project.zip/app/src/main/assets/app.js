const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const K={plan:"ef_plan",errors:"ef_errors",stats:"ef_stats",streak:"ef_streak",theme:"ef_theme",mastery:"ef_mastery",notif:"ef_notif",focus:"ef_focus_sessions",goal:"ef_weekly_goal",flash:"ef_flashcards",notes:"ef_notes",tasks:"ef_tasks",exams:"ef_exams",resources:"ef_resources",dailyTarget:"ef_daily_target"};
let plan=load(K.plan,null), errors=load(K.errors,[]), stats=load(K.stats,[]), streak=load(K.streak,{days:[],xp:0}), mastery=load(K.mastery,{}), focusSessions=load(K.focus,[]), weeklyGoal=load(K.goal,300), flashcards=load(K.flash,[]), notes=load(K.notes,[]), tasks=load(K.tasks,[]), exams=load(K.exams,[]), resources=load(K.resources,[]), dailyTarget=load(K.dailyTarget,60);
let currentScreen="home", quizMode="practice", currentQuiz=null;

function load(k,d){try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}}
let cloudReady=false,cloudTimer=null,currentUser=null;
function save(k,v){localStorage.setItem(k,JSON.stringify(v));if(cloudReady){clearTimeout(cloudTimer);cloudTimer=setTimeout(saveCloudState,700)}}
function snapshot(){return {plan,errors,stats,streak,mastery,focusSessions,weeklyGoal,flashcards,notes,tasks,exams,resources,dailyTarget,theme:load(K.theme,false),notif:load(K.notif,false)}}
function toast(t){const el=$("#toast");el.textContent=t;el.classList.remove("hidden");setTimeout(()=>el.classList.add("hidden"),2200)}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function d0(){let d=new Date();d.setHours(12,0,0,0);return d}
function dateOnly(s){return new Date(s+"T12:00:00")}
function iso(d){return d.toISOString().slice(0,10)}
function addDays(d,n){let x=new Date(d);x.setDate(x.getDate()+n);return x}
function localDay(d=new Date()){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`}

const dayLabels=["Dom","Lun","Mar","Mer","Gio","Ven","Sab"];
let selectedDays=new Set([1,2,3,4,5]);
dayLabels.forEach((x,i)=>{const b=document.createElement("button");b.className="day-pill"+(selectedDays.has(i)?" active":"");b.textContent=x;b.onclick=()=>{selectedDays.has(i)?selectedDays.delete(i):selectedDays.add(i);b.classList.toggle("active")};$("#days").appendChild(b)});

function go(screen){
  if(screen==="stats"){}
  currentScreen=screen;
  $$(".screen").forEach(x=>x.classList.toggle("active",x.dataset.screen===screen));
  $$(".nav").forEach(x=>x.classList.toggle("active",x.dataset.goto===screen));
  const sub={home:"Il tuo piano verso l’esame",plan:"Organizza ogni giornata",quiz:"Allenati con l’AI",review:"Trasforma gli errori in punti forti",stats:"Misura i tuoi progressi",profile:"Personalizza ExamFlow"}[screen];
  $("#topSubtitle").textContent=sub||"ExamFlow";
  window.scrollTo({top:0,behavior:"smooth"});
  render();
}
$$("[data-goto]").forEach(b=>b.onclick=()=>go(b.dataset.goto));
window.examflowBack=()=>{if(currentScreen!=="home"){go("home");return true}return false};

function applyTheme(){
  const dark=load(K.theme,false); document.body.classList.toggle("dark",dark);
}
function toggleTheme(){save(K.theme,!load(K.theme,false));applyTheme()}
$("#themeBtn").onclick=toggleTheme; $("#themeSetting").onclick=toggleTheme; applyTheme();

function buildPlan(){
  const subject=$("#subject").value.trim(), examDate=$("#examDate").value, total=+$("#totalUnits").value;
  if(!subject||!examDate||!total)return toast("Completa materia, data e quantità totale.");
  if(!selectedDays.size)return toast("Seleziona almeno un giorno.");
  const exam=dateOnly(examDate), today=d0(); if(exam<=today)return toast("La data dell’esame deve essere futura.");
  const available=[]; for(let d=new Date(today);d<exam;d=addDays(d,1)) if(selectedDays.has(d.getDay())) available.push(new Date(d));
  if(!available.length)return toast("Non ci sono giorni disponibili.");
  const reviewDays=Math.min(+$("#reviewDays").value||0,Math.max(0,available.length-1));
  const studyDays=available.slice(0,available.length-reviewDays), review=available.slice(available.length-reviewDays);
  if(!studyDays.length)return toast("Riduci i giorni finali di ripasso.");
  const topics=$("#syllabus").value.split(/\n|,/).map(x=>x.trim()).filter(Boolean);
  const base=Math.floor(total/studyDays.length), rem=total%studyDays.length; let cursor=1;
  const schedule=studyDays.map((d,i)=>{const amount=base+(i<rem?1:0),from=cursor,to=cursor+amount-1;cursor=to+1;const a=Math.floor(i*topics.length/studyDays.length),b=Math.floor((i+1)*topics.length/studyDays.length);return{id:`s-${i}-${iso(d)}`,date:iso(d),type:"study",amount,from,to,topics:topics.slice(a,Math.max(a+1,b)),done:false}});
  review.forEach((d,i)=>schedule.push({id:`r-${i}-${iso(d)}`,date:iso(d),type:"review",done:false}));
  plan={subject,examDate,totalUnits:total,unitType:$("#unitType").value,hoursPerDay:+$("#hoursPerDay").value,reviewDays,selectedDays:[...selectedDays],topics,schedule};
  save(K.plan,plan); toast("Piano creato."); render(); go("home");
}
$("#createPlanBtn").onclick=buildPlan;
$("#newPlanBtn").onclick=()=>{if(plan&&!confirm("Creare un nuovo piano?"))return;plan=null;save(K.plan,null);render()};
$("#printBtn").onclick=()=>window.print();

function progressPct(){
  if(!plan?.schedule?.length)return 0;
  return Math.round(100*plan.schedule.filter(x=>x.done).length/plan.schedule.length);
}
function daysLeft(){return plan?Math.max(0,Math.ceil((dateOnly(plan.examDate)-d0())/86400000)):0}
function streakCount(){
  let n=0,d=new Date();for(;;){if((streak.days||[]).includes(localDay(d))){n++;d.setDate(d.getDate()-1)}else break}return n
}
function readiness(){
  const recent=stats.slice(0,10),avg=recent.length?recent.reduce((a,b)=>a+b.pct,0)/recent.length:0,p=progressPct(),vol=Math.min(100,recent.length*10);
  return Math.round(avg*.65+p*.25+vol*.10)
}

function topicMastery(name){
  const m=mastery[name]||{correct:0,wrong:0,streak:0};
  const total=m.correct+m.wrong;
  if(!total)return 0;
  return Math.max(0,Math.min(100,Math.round((m.correct/total)*70 + Math.min(30,m.streak*10))));
}
function masteryLabel(v){
  if(v>=80)return "Consolidato";
  if(v>=60)return "Buono";
  if(v>=35)return "Da rinforzare";
  return "In apprendimento";
}
function updateMastery(topic,ok){
  if(!topic)return;
  const m=mastery[topic]||{correct:0,wrong:0,streak:0};
  if(ok){m.correct++;m.streak=(m.streak||0)+1}else{m.wrong++;m.streak=0}
  mastery[topic]=m;save(K.mastery,mastery);
}
function renderMastery(){
  const home=$("#masteryHome"), list=$("#masteryList");
  const topics=plan?.topics?.length?plan.topics:Object.keys(mastery);
  const rows=[...new Set(topics)].slice(0,30).map(t=>({t,v:topicMastery(t)})).sort((a,b)=>a.v-b.v);
  if(home){
    if(!rows.length)home.innerHTML='<div class="empty-state">Completa qualche quiz per vedere la padronanza degli argomenti.</div>';
    else home.innerHTML=rows.slice(0,4).map(x=>`<div class="mastery-row"><div><div class="label">${esc(x.t)}</div><div class="mastery-bar"><span style="width:${x.v}%"></span></div><div class="meta">${x.v}%</div></div><span class="mastery-badge">${masteryLabel(x.v)}</span></div>`).join("");
  }
  if(list){
    list.innerHTML=rows.length?rows.map(x=>`<div class="mastery-item"><b>${esc(x.t)}</b><small>${masteryLabel(x.v)} · ${x.v}%</small><div class="mastery-bar"><span style="width:${x.v}%"></span></div></div>`).join(""):'<div class="empty-state">Nessun dato di padronanza disponibile.</div>';
  }
}
function rebalancePlan(){
  if(!plan?.schedule?.length)return;
  const today=iso(d0());
  const weakTopics=(plan.topics||[]).map(t=>({t,v:topicMastery(t)})).sort((a,b)=>a.v-b.v).slice(0,Math.max(1,Math.ceil((plan.topics||[]).length/3))).map(x=>x.t);
  const future=plan.schedule.filter(x=>x.type==="study"&&!x.done&&x.date>=today);
  if(!future.length)return;
  future.forEach((x,i)=>{
    const weak=weakTopics.filter(t=>(x.topics||[]).includes(t));
    x.priority=weak.length?"high":"normal";
  });
}


function startOfWeek(){
  const d=new Date();d.setHours(0,0,0,0);
  const day=(d.getDay()+6)%7;d.setDate(d.getDate()-day);return d;
}
function weekFocusMinutes(){
  const start=startOfWeek().getTime();
  return focusSessions.filter(s=>new Date(s.date).getTime()>=start).reduce((n,s)=>n+(s.minutes||0),0);
}
function renderWeeklyGoal(){
  const mins=weekFocusMinutes(), pct=Math.min(100,Math.round(mins/Math.max(1,weeklyGoal)*100));
  const t=$("#weeklyGoalText"),b=$("#weeklyGoalBar");
  if(t)t.textContent=`${mins} / ${weeklyGoal} min`;
  if(b)b.style.width=pct+"%";
  const wm=$("#weekMinutes"),ts=$("#totalSessions");
  if(wm)wm.textContent=mins;if(ts)ts.textContent=focusSessions.length;
}
function renderFlashcards(){
  const area=$("#flashCardArea");if(!area)return;
  if(!flashcards.length){area.innerHTML='<div class="flash-empty">Nessuna flashcard. Creane una qui sotto oppure trasformane una dai tuoi appunti.</div>';return}
  const due=dueFlashcards();const f=due[0]||flashcards[0];
  area.innerHTML=`<div class="flashcard" id="activeFlash"><div class="front">${esc(f.front)}</div><div class="back">${esc(f.back)}</div></div><div class="flash-controls"><button id="flashAgain" class="secondary-btn">Da rivedere</button><button id="flashKnown" class="primary-btn">La so</button></div><p class="muted tiny">${flashcards.length} flashcard disponibili · Tocca la carta per girarla</p>`;
  $("#activeFlash").onclick=()=>$("#activeFlash").classList.toggle("flipped");
  $("#flashAgain").onclick=()=>{scheduleFlashcard(f,"again");save(K.flash,flashcards);renderFlashcards();renderDueReview()};
  $("#flashKnown").onclick=()=>{f.known=(f.known||0)+1;scheduleFlashcard(f,"good");save(K.flash,flashcards);renderFlashcards();renderDueReview();toast(f.stage>=5?"Flashcard molto ben consolidata.":"Prossimo ripasso programmato.")};
}


function nowDay(){return localDay(new Date())}
function scheduleFlashcard(card,quality){
  const today=new Date();
  const stage=card.stage||0;
  let days=1;
  if(quality==="good") days=[1,3,7,14,30,60][Math.min(stage,5)];
  if(quality==="again") days=1;
  card.stage=quality==="good"?Math.min(stage+1,5):0;
  const due=new Date(today);due.setDate(due.getDate()+days);
  card.due=localDay(due);
  return card;
}
function dueFlashcards(){
  const today=nowDay();
  return flashcards.filter(f=>!f.due||f.due<=today);
}
function renderDueReview(){
  const due=dueFlashcards();
  const t=$("#dueReviewText");
  if(t)t.textContent=due.length?`${due.length} flashcard da ripassare oggi`:"Nessuna flashcard in scadenza";
}
function renderNotes(){
  const el=$("#notesList");if(!el)return;
  if(!notes.length){el.innerHTML='<div class="empty-state">Nessun appunto salvato.</div>';return}
  el.innerHTML=notes.map((n,i)=>`<div class="note-item"><h4>${esc(n.title||"Appunto")}</h4><p>${esc(n.body||"")}</p><div class="note-actions"><button data-note-edit="${i}">Modifica</button><button data-note-delete="${i}">Elimina</button></div></div>`).join("");
  $$("[data-note-edit]").forEach(b=>b.onclick=()=>{
    const i=+b.dataset.noteEdit,n=notes[i];$("#noteTitle").value=n.title||"";$("#noteBody").value=n.body||"";
    notes.splice(i,1);save(K.notes,notes);renderNotes();
  });
  $$("[data-note-delete]").forEach(b=>b.onclick=()=>{notes.splice(+b.dataset.noteDelete,1);save(K.notes,notes);renderNotes();toast("Appunto eliminato.")});
}
function cleanOldTasks(){
  const today=nowDay();
  tasks=tasks.filter(t=>t.date===today || !t.done);
}
function renderTasks(){
  cleanOldTasks();
  const el=$("#tasksList");if(!el)return;
  if(!tasks.length){el.innerHTML='<div class="empty-state">Nessun obiettivo per oggi.</div>';return}
  el.innerHTML=tasks.map((t,i)=>`<div class="task-item ${t.done?"done":""}"><input type="checkbox" data-task-check="${i}" ${t.done?"checked":""}><span>${esc(t.text)}</span><button class="delete-task" data-task-delete="${i}">×</button></div>`).join("");
  $$("[data-task-check]").forEach(c=>c.onchange=()=>{tasks[+c.dataset.taskCheck].done=c.checked;save(K.tasks,tasks);renderTasks();renderAchievements()});
  $$("[data-task-delete]").forEach(b=>b.onclick=()=>{tasks.splice(+b.dataset.taskDelete,1);save(K.tasks,tasks);renderTasks()});
}
function renderAchievements(){
  const el=$("#achievementsGrid");if(!el)return;
  const completedTasks=tasks.filter(t=>t.done).length;
  const completedSessions=focusSessions.length;
  const quizCount=stats.length;
  const mastered=Object.keys(mastery).filter(k=>topicMastery(k)>=80).length;
  const data=[
    {icon:"🔥",name:"Costanza",desc:"Streak di 7 giorni",ok:streakCount()>=7},
    {icon:"🎯",name:"Quiz Master",desc:"10 quiz completati",ok:quizCount>=10},
    {icon:"🧠",name:"Memoria forte",desc:"5 argomenti consolidati",ok:mastered>=5},
    {icon:"⏱",name:"Focus",desc:"10 sessioni completate",ok:completedSessions>=10},
    {icon:"✅",name:"Organizzato",desc:"5 attività completate",ok:completedTasks>=5},
    {icon:"⚡",name:"100 XP",desc:"Raggiungi 100 XP",ok:(streak.xp||0)>=100}
  ];
  el.innerHTML=data.map(a=>`<div class="achievement ${a.ok?"":"locked"}"><div class="icon">${a.icon}</div><b>${a.name}</b><small>${a.ok?"Sbloccato":a.desc}</small></div>`).join("");
}


function daysUntil(dateStr){
  if(!dateStr)return 0;
  const today=new Date();today.setHours(0,0,0,0);
  const d=new Date(dateStr+"T00:00:00");
  return Math.ceil((d-today)/86400000);
}
function renderExams(){
  exams=exams.filter(x=>x&&x.name&&x.date);
  exams.sort((a,b)=>a.date.localeCompare(b.date));
  const list=$("#examsList"), statsEl=$("#examStatsList");
  const row=x=>{
    const d=daysUntil(x.date),label=d<0?`${Math.abs(d)} giorni fa`:d===0?"Oggi":`${d} giorni`;
    return `<div class="exam-item"><div><b>${esc(x.name)}</b><small>${new Date(x.date+"T00:00:00").toLocaleDateString("it-IT")} · ${label}</small></div><div class="exam-days">${d>=0?d:"✓"}</div><div class="exam-actions"><button data-exam-plan="${x.id}">Usa nel piano</button><button data-exam-del="${x.id}">Elimina</button></div></div>`;
  };
  if(list){
    list.innerHTML=exams.length?exams.map(row).join(""):'<div class="empty-state">Nessun esame salvato.</div>';
    $$("[data-exam-del]").forEach(b=>b.onclick=()=>{exams=exams.filter(x=>x.id!==b.dataset.examDel);save(K.exams,exams);renderExams();toast("Esame eliminato.")});
    $$("[data-exam-plan]").forEach(b=>b.onclick=()=>{
      const x=exams.find(e=>e.id===b.dataset.examPlan);if(!x)return;
      $("#subject").value=x.name;$("#examDate").value=x.date;$("#examsSheet").classList.add("hidden");go("plan");toast("Esame caricato nel piano.");
    });
  }
  if(statsEl){
    const upcoming=exams.filter(x=>daysUntil(x.date)>=0).slice(0,4);
    statsEl.innerHTML=upcoming.length?upcoming.map(x=>`<div class="exam-stat"><b>${esc(x.name)}</b><small>${daysUntil(x.date)===0?"Oggi":daysUntil(x.date)+" giorni"} · ${new Date(x.date+"T00:00:00").toLocaleDateString("it-IT")}</small></div>`).join(""):'<div class="empty-state">Aggiungi un esame per vedere il conto alla rovescia.</div>';
  }
}
function renderResources(){
  const el=$("#resourcesList");if(!el)return;
  if(!resources.length){el.innerHTML='<div class="empty-state">Nessun materiale salvato.</div>';return}
  el.innerHTML=resources.map((r,i)=>`<div class="resource-item"><b>${esc(r.title||"Materiale")}</b>${r.url?`<small class="resource-url">${esc(r.url)}</small>`:""}${r.note?`<p>${esc(r.note)}</p>`:""}<div class="resource-actions">${r.url?`<button data-res-open="${i}">Apri</button>`:""}<button data-res-del="${i}">Elimina</button></div></div>`).join("");
  $$("[data-res-open]").forEach(b=>b.onclick=()=>{
    const r=resources[+b.dataset.resOpen];if(r?.url){try{location.href=r.url}catch(e){toast("Impossibile aprire il link.")}}
  });
  $$("[data-res-del]").forEach(b=>b.onclick=()=>{resources.splice(+b.dataset.resDel,1);save(K.resources,resources);renderResources()});
}
function searchAll(q){
  const query=(q||"").trim().toLowerCase();
  if(!query)return [];
  const out=[];
  notes.forEach(n=>{if(`${n.title} ${n.body}`.toLowerCase().includes(query))out.push({kind:"Appunto",title:n.title||"Appunto",text:n.body||""})});
  tasks.forEach(t=>{if((t.text||"").toLowerCase().includes(query))out.push({kind:"Checklist",title:t.text,text:t.done?"Completata":"Da fare"})});
  flashcards.forEach(f=>{if(`${f.front} ${f.back}`.toLowerCase().includes(query))out.push({kind:"Flashcard",title:f.front,text:f.back})});
  resources.forEach(r=>{if(`${r.title} ${r.note} ${r.url}`.toLowerCase().includes(query))out.push({kind:"Materiale",title:r.title||"Materiale",text:r.note||r.url||""})});
  exams.forEach(e=>{if((e.name||"").toLowerCase().includes(query))out.push({kind:"Esame",title:e.name,text:e.date})});
  return out.slice(0,50);
}
function renderSearch(q=""){
  const el=$("#globalSearchResults");if(!el)return;
  const results=searchAll(q);
  if(!q.trim()){el.innerHTML='<div class="search-empty">Scrivi qualcosa per cercare in appunti, checklist, flashcard, materiali ed esami.</div>';return}
  if(!results.length){el.innerHTML='<div class="search-empty">Nessun risultato.</div>';return}
  el.innerHTML=results.map(r=>`<div class="search-result"><div class="kind">${esc(r.kind)}</div><b>${esc(r.title)}</b><small>${esc(r.text)}</small></div>`).join("");
}
function renderDailyScore(){
  const today=nowDay();
  const todayTasks=tasks.filter(t=>t.date===today);
  const taskScore=todayTasks.length?todayTasks.filter(t=>t.done).length/todayTasks.length:0;
  const todayFocus=focusSessions.filter(s=>(s.date||"").slice(0,10)===today).reduce((n,s)=>n+(s.minutes||0),0);
  const focusScore=Math.min(1,todayFocus/Math.max(1,dailyTarget));
  const todayQuiz=stats.filter(s=>(s.date||"").slice(0,10)===today).length;
  const quizScore=Math.min(1,todayQuiz/2);
  const score=Math.round((taskScore*.4+focusScore*.35+quizScore*.25)*100);
  const ring=$("#dailyScoreRing"),val=$("#dailyScoreValue"),title=$("#dailyScoreTitle"),meta=$("#dailyScoreMeta");
  if(ring)ring.style.setProperty("--score",score);
  if(val)val.textContent=score+"%";
  if(title)title.textContent=score>=80?"Giornata molto produttiva":score>=50?"Buon ritmo":score>0?"Continua così":"Inizia con un piccolo obiettivo";
  if(meta)meta.textContent=`${todayFocus} min focus · ${todayTasks.filter(t=>t.done).length}/${todayTasks.length} attività · ${todayQuiz} quiz`;
}


function nearestExam(){
  return exams.filter(e=>daysUntil(e.date)>=0).sort((a,b)=>a.date.localeCompare(b.date))[0]||null;
}
function weakestTopic(){
  const topics=[...new Set([...(plan?.topics||[]),...Object.keys(mastery)])];
  return topics.map(t=>({t,v:topicMastery(t)})).sort((a,b)=>a.v-b.v)[0]||null;
}
function renderSmartSuggestion(){
  const title=$("#smartSuggestionTitle"),text=$("#smartSuggestionText"),btn=$("#smartSuggestionBtn");
  if(!title||!text||!btn)return;
  const today=nowDay();
  const pendingTasks=tasks.filter(t=>t.date===today&&!t.done);
  const due=dueFlashcards();
  const weak=weakestTopic();
  const exam=nearestExam();

  if(pendingTasks.length){
    title.textContent=`Completa ${pendingTasks.length} attività di oggi`;
    text.textContent=pendingTasks[0].text;
    btn.textContent="Checklist";btn.onclick=()=>{$("#tasksSheet").classList.remove("hidden");renderTasks()};return;
  }
  if(due.length){
    title.textContent=`Hai ${due.length} flashcard da ripassare`;
    text.textContent="Un breve ripasso ora aiuta a mantenere le informazioni nel tempo.";
    btn.textContent="Ripassa";btn.onclick=()=>{$("#flashSheet").classList.remove("hidden");renderFlashcards()};return;
  }
  if(weak && weak.v<70){
    title.textContent=`Rinforza: ${weak.t}`;
    text.textContent=`Padronanza attuale ${weak.v}%. Un quiz breve può aiutarti a consolidare l'argomento.`;
    btn.textContent="Quiz";btn.onclick=()=>{$("#aiSubject").value=plan?.subject||"";$("#aiTopic").value=weak.t;go("quiz")};return;
  }
  if(exam){
    const d=daysUntil(exam.date);
    title.textContent=d===0?`${exam.name}: oggi`:`${exam.name}: ${d} giorni`;
    text.textContent="Mantieni il ritmo con una sessione Focus o un ripasso mirato.";
    btn.textContent="Focus";btn.onclick=()=>{$("#focusSheet").classList.remove("hidden");paintFocus()};return;
  }
  title.textContent="Configura il tuo primo obiettivo";
  text.textContent="Aggiungi un esame o crea un piano per ricevere suggerimenti personalizzati.";
  btn.textContent="Piano";btn.onclick=()=>go("plan");
}
function todayStudyMinutes(){
  const today=nowDay();
  return focusSessions.filter(s=>(s.date||"").slice(0,10)===today).reduce((n,s)=>n+(s.minutes||0),0);
}
function updateDailyTargetState(){
  const el=$("#dailyTargetState");if(el)el.textContent=`${dailyTarget} min al giorno`;
}
function updateSyncStatus(text,mode){
  const el=$("#syncStatus");if(!el)return;
  el.textContent=text;el.classList.remove("online","offline");
  if(mode)el.classList.add(mode);
}

function renderHome(){
  rebalancePlan();
  $("#homeSubject").textContent=plan?.subject||"Nessun esame attivo";
  $("#homeExamMeta").textContent=plan?`${dateOnly(plan.examDate).toLocaleDateString("it-IT")} · ${daysLeft()} giorni rimasti`:"Crea un piano per iniziare.";
  const p=progressPct();$("#ringValue").textContent=p+"%";$("#progressRing").style.setProperty("--p",p);
  $("#daysMetric").textContent=daysLeft();$("#streakMetric").textContent=streakCount();$("#xpMetric").textContent=streak.xp||0;
  const c=$("#todayCard");
  if(!plan){c.className="card empty-state";c.textContent="Crea un piano per vedere l’obiettivo di oggi.";return}
  const t=iso(d0()), x=plan.schedule.find(x=>x.date===t&&!x.done)||plan.schedule.find(x=>x.date>=t&&!x.done);
  if(!x){c.className="card empty-state";c.textContent="Piano completato. Ottimo lavoro.";return}
  const d=dateOnly(x.date);c.className="card";const priorityNote=x.priority==="high"?'<div class="plan-alert">Priorità alta: questo blocco contiene argomenti deboli.</div>':"";c.innerHTML=`<div class="eyebrow">${d.toLocaleDateString("it-IT",{weekday:"long",day:"numeric",month:"long"})}</div><h3>${x.type==="study"?`Studia ${x.amount} ${esc(plan.unitType)}`:"Giornata di ripasso"}</h3><p class="muted">${x.type==="study"?`${x.from}–${x.to}${x.topics?.length?` · ${x.topics.map(esc).join(", ")}`:""}`:"Concentrati sugli errori e sugli argomenti deboli."}</p>${priorityNote}<button id="todayStart" class="primary-btn">Inizia ora</button>`;
  $("#todayStart").onclick=()=>{if(x.type==="study"){$("#aiSubject").value=plan.subject;$("#aiTopic").value=x.topics?.join(", ")||`${plan.unitType} ${x.from}-${x.to}`;go("quiz")}else go("review")}
}
function renderPlan(){
  $("#planBuilder").classList.toggle("hidden",!!plan);$("#planActive").classList.toggle("hidden",!plan);
  if(!plan)return;
  const p=progressPct();$("#planSummaryTitle").textContent=plan.subject;$("#planSummaryMeta").textContent=`Esame ${dateOnly(plan.examDate).toLocaleDateString("it-IT")} · ${p}% completato`;$("#planPct").textContent=p+"%";$(".mini-ring").style.setProperty("--p",p);
  const el=$("#schedule");el.innerHTML="";
  plan.schedule.forEach((x,i)=>{const d=dateOnly(x.date),m=d.toLocaleDateString("it-IT",{month:"short"}).replace(".","");const row=document.createElement("div");row.className="timeline-item"+(x.done?" done":"");row.innerHTML=`<div class="date-badge"><div>${d.getDate()}<br><small>${m.toUpperCase()}</small></div></div><div><b>${x.type==="study"?`${x.amount} ${esc(plan.unitType)} · ${x.from}-${x.to}`:"Ripasso finale"}</b><div class="muted tiny">${x.type==="study"?(x.topics?.map(esc).join(" · ")||"Sessione di studio"):"Errori, quiz e simulazione"}</div></div><input type="checkbox" ${x.done?"checked":""}>`;row.querySelector("input").onchange=e=>{plan.schedule[i].done=e.target.checked;save(K.plan,plan);render()};el.appendChild(row)})
}
$("#lateBtn").onclick=()=>{if(!plan)return;const today=iso(d0()),missed=plan.schedule.filter(x=>x.type==="study"&&!x.done&&x.date<today).reduce((s,x)=>s+x.amount,0),future=plan.schedule.filter(x=>x.type==="study"&&!x.done&&x.date>=today);if(!missed)return toast("Non risultano unità arretrate.");if(!future.length)return toast("Nessun giorno futuro disponibile.");const total=future.reduce((s,x)=>s+x.amount,0)+missed,base=Math.floor(total/future.length),rem=total%future.length;let start=plan.schedule.filter(x=>x.type==="study"&&x.done).reduce((s,x)=>s+x.amount,0)+1;plan.schedule=plan.schedule.filter(x=>!(x.type==="study"&&!x.done&&x.date<today));plan.schedule.filter(x=>x.type==="study"&&!x.done).forEach((x,i)=>{x.amount=base+(i<rem?1:0);x.from=start;x.to=start+x.amount-1;start=x.to+1});save(K.plan,plan);render();toast("Piano ricalcolato.")};

$$(".seg").forEach(b=>b.onclick=()=>{$$(".seg").forEach(x=>x.classList.remove("active"));b.classList.add("active");quizMode=b.dataset.mode});
async function nativeGenerateQuiz(payload){
  if(!currentUser) throw new Error("Accedi per usare i Quiz AI.");
  const r=await bridgeCall("generateQuiz",JSON.stringify(payload));
  if(!r.ok) throw new Error(r?.data?.error||r?.data?.message||"Errore nella generazione del quiz.");
  return r.data;
}
$("#generateQuizBtn").onclick=async()=>{const subject=$("#aiSubject").value.trim(),topic=$("#aiTopic").value.trim();if(!subject||!topic)return toast("Inserisci materia e argomento.");$("#quizStatus").textContent="Genero il quiz...";$("#generateQuizBtn").disabled=true;try{const d=await nativeGenerateQuiz({subject,topic,difficulty:$("#aiDifficulty").value,count:+$("#aiCount").value,type:$("#aiType")?.value||"mixed"});startQuiz(d.questions,{subject,topic,type:$("#aiType")?.value||"mixed"})}catch(e){$("#quizStatus").textContent=e.message}finally{$("#generateQuizBtn").disabled=false}};
function startQuiz(qs,meta){currentQuiz={questions:qs,answers:Array(qs.length).fill(null),meta};$("#quizArea").innerHTML="";qs.forEach((q,i)=>{const c=document.createElement("div");c.className="card question";c.innerHTML=`<h3>${i+1}. ${esc(q.question)}</h3><div class="options"></div>`;q.options.forEach((o,j)=>{const b=document.createElement("button");b.className="option";b.textContent=o;b.onclick=()=>answerQuiz(i,j,c,b);c.querySelector(".options").appendChild(b)});$("#quizArea").appendChild(c)});$("#quizStatus").textContent=`${qs.length} domande pronte.`}
function answerQuiz(i,j,c,b){if(currentQuiz.answers[i]!==null)return;const q=currentQuiz.questions[i],ok=j===q.correctIndex;currentQuiz.answers[i]=ok;c.querySelectorAll(".option").forEach((x,k)=>{x.disabled=true;if(k===q.correctIndex)x.classList.add("correct")});updateMastery(currentQuiz.meta.topic,ok);if(!ok){b.classList.add("wrong");errors.unshift({q:q.question,a:q.options[q.correctIndex],explanation:q.explanation||"",subject:currentQuiz.meta.subject,topic:currentQuiz.meta.topic,date:new Date().toISOString(),masteredCount:0});save(K.errors,errors.slice(0,200))}const p=document.createElement("p");p.className="muted";p.textContent=(ok?"Corretto. ":"Da ripassare. ")+(q.explanation||"");c.appendChild(p);if(currentQuiz.answers.every(x=>x!==null))finishQuiz()}
function finishQuiz(){const total=currentQuiz.answers.length,correct=currentQuiz.answers.filter(Boolean).length,pct=Math.round(correct/total*100);stats.unshift({subject:currentQuiz.meta.subject,topic:currentQuiz.meta.topic,correct,total,pct,date:new Date().toISOString()});stats=stats.slice(0,100);save(K.stats,stats);const today=localDay();if(!(streak.days||[]).includes(today)){streak.days=(streak.days||[]).concat(today).slice(-365);streak.xp=(streak.xp||0)+10;save(K.streak,streak)}const r=document.createElement("div");r.className="card quiz-result";r.innerHTML=`<b>${pct}%</b><h3>${pct>=80?"Ottima preparazione":pct>=60?"Buona base":"Da rinforzare"}</h3><p>${correct}/${total} corrette</p>`;$("#quizArea").appendChild(r);render()}
$("#smartReviewBtn").onclick=()=>{if(!errors.length)return toast("Non hai errori da ripassare.");$("#aiSubject").value=errors.find(x=>x.subject)?.subject||"Ripasso";$("#aiTopic").value=[...new Set(errors.slice(0,10).map(x=>x.topic).filter(Boolean))].join(", ")||errors.slice(0,4).map(x=>x.q).join(" · ");go("quiz")};

function renderReview(){
  $("#errorMetric").textContent=errors.length;$("#weakMetric").textContent=new Set(errors.map(x=>x.topic).filter(Boolean)).size;$("#noErrors").classList.toggle("hidden",errors.length>0);const el=$("#errorsList");el.innerHTML="";
  errors.slice(0,50).forEach((e,i)=>{const c=document.createElement("div");c.className="card error-card";c.innerHTML=`<div class="tag">${esc(e.subject||"Ripasso")}</div><b>${esc(e.q)}</b><p>Risposta: ${esc(e.a)}</p>${e.explanation?`<p>${esc(e.explanation)}</p>`:""}<button>Padroneggiato</button>`;c.querySelector("button").onclick=()=>{e.masteredCount=(e.masteredCount||0)+1;if(e.masteredCount>=2){errors.splice(i,1);toast("Errore consolidato e rimosso.")}else{errors[i]=e;toast("Conferma ancora una volta dopo un altro ripasso.")}save(K.errors,errors);render()};el.appendChild(c)})
}
function renderStats(){
  const recent=stats.slice(0,10),avg=recent.length?Math.round(recent.reduce((a,b)=>a+b.pct,0)/recent.length):0;$("#avgStat").textContent=avg+"%";$("#readyStat").textContent=readiness()+"%";$("#statsStreak").textContent=streakCount();$("#statsXp").textContent=streak.xp||0;$("#statsLevel").textContent=Math.floor((streak.xp||0)/100)+1;
  const ch=$("#chart");ch.innerHTML="";(recent.length?recent.slice().reverse():[0,0,0,0,0]).forEach((x,i)=>{const val=typeof x==="number"?x:x.pct,b=document.createElement("div");b.className="bar";b.style.height=Math.max(4,val)+"%";b.innerHTML=`<small>${val}%</small>`;ch.appendChild(b)})
}
$("#rescueQuick").onclick=()=>{const c=$("#rescueContent");if(!plan){c.innerHTML="<p>Crea prima un piano di studio.</p>"}else{const days=daysLeft(),pending=plan.schedule.filter(x=>!x.done),study=pending.filter(x=>x.type==="study"),daily=study.length?Math.max(1,Math.ceil(study.length/Math.max(1,days-Math.min(3,days)))):0,weak=[...new Set(errors.map(x=>x.topic).filter(Boolean))].slice(0,3);c.innerHTML=`<div class="rescue-step"><b>Tempo</b><p>${days} giorni · ${pending.length} sessioni aperte</p></div><div class="rescue-step"><b>1. Priorità</b><p>${daily} sessioni di studio al giorno.</p></div><div class="rescue-step"><b>2. Verifica</b><p>Un quiz breve dopo ogni blocco.</p></div><div class="rescue-step"><b>3. Errori</b><p>${weak.length?`Concentrati su ${weak.map(esc).join(", ")}.`:"Ripassa gli errori ogni sera."}</p></div><div class="rescue-step"><b>4. Simulazione</b><p>${days<=7?"Una al giorno.":"Una ogni 2–3 giorni."}</p></div>`}$("#rescueSheet").classList.remove("hidden")};
$("#closeRescue").onclick=()=>$("#rescueSheet").classList.add("hidden");
$("#rescueSheet").onclick=e=>{if(e.target===$("#rescueSheet"))$("#rescueSheet").classList.add("hidden")};

$("#exportBtn").onclick=()=>{const data=JSON.stringify({plan,errors,stats,streak,mastery,focusSessions,weeklyGoal,flashcards,notes,tasks,exams,resources,dailyTarget,theme:load(K.theme,false)},null,2);prompt("Copia questo backup:",data)};
$("#resetAllBtn").onclick=()=>{if(confirm("Cancellare tutti i dati locali?")){Object.values(K).forEach(k=>localStorage.removeItem(k));plan=null;errors=[];stats=[];streak={days:[],xp:0};mastery={};focusSessions=[];weeklyGoal=300;flashcards=[];notes=[];tasks=[];exams=[];resources=[];dailyTarget=60;render();toast("Dati cancellati.")}};

function render(){renderHome();renderPlan();renderReview();renderStats();renderMastery();renderWeeklyGoal();renderFlashcards();renderDueReview();renderNotes();renderTasks();renderAchievements();renderExams();renderResources();renderDailyScore();renderSmartSuggestion();updateDailyTargetState()}

function bridgeCall(method,...args){
  return new Promise((resolve,reject)=>{
    if(!window.AndroidBridge || typeof window.AndroidBridge[method]!=="function") return reject(new Error("Servizio non disponibile."));
    const cb="cb_"+Date.now()+"_"+Math.random().toString(36).slice(2);
    window.__cbs=window.__cbs||{};
    window.__cbs[cb]=(ok,data)=>{
      try{
        const d=JSON.parse(data);
        if(!ok) reject(new Error(d.error||"Errore di rete"));
        else resolve(d);
      }catch(e){reject(e)}
      delete window.__cbs[cb];
    };
    window.AndroidBridge[method](...args,cb);
  });
}

async function saveCloudState(){
  if(!cloudReady)return;
  updateSyncStatus("Sincronizzo…","online");
  try{await bridgeCall("saveCloud",JSON.stringify(snapshot()));updateSyncStatus("Sincronizzato","online")}catch(e){updateSyncStatus("Offline","offline")}
}
async function loadCloudState(){
  try{
    const r=await bridgeCall("loadCloud");
    const d=r.data||{};
    if(d.state){
      const s=d.state;
      if("plan" in s){plan=s.plan;localStorage.setItem(K.plan,JSON.stringify(plan))}
      if(Array.isArray(s.errors)){errors=s.errors;localStorage.setItem(K.errors,JSON.stringify(errors))}
      if(Array.isArray(s.stats)){stats=s.stats;localStorage.setItem(K.stats,JSON.stringify(stats))}
      if(s.streak){streak=s.streak;localStorage.setItem(K.streak,JSON.stringify(streak))}
      if(s.mastery&&typeof s.mastery==="object"){mastery=s.mastery;localStorage.setItem(K.mastery,JSON.stringify(mastery))}
      if(typeof s.notif==="boolean")localStorage.setItem(K.notif,JSON.stringify(s.notif))
      if(Array.isArray(s.focusSessions)){focusSessions=s.focusSessions;localStorage.setItem(K.focus,JSON.stringify(focusSessions))}
      if(Number.isFinite(s.weeklyGoal)){weeklyGoal=s.weeklyGoal;localStorage.setItem(K.goal,JSON.stringify(weeklyGoal))}
      if(Array.isArray(s.flashcards)){flashcards=s.flashcards;localStorage.setItem(K.flash,JSON.stringify(flashcards))}
      if(Array.isArray(s.notes)){notes=s.notes;localStorage.setItem(K.notes,JSON.stringify(notes))}
      if(Array.isArray(s.tasks)){tasks=s.tasks;localStorage.setItem(K.tasks,JSON.stringify(tasks))}
      if(Array.isArray(s.exams)){exams=s.exams;localStorage.setItem(K.exams,JSON.stringify(exams))}
      if(Array.isArray(s.resources)){resources=s.resources;localStorage.setItem(K.resources,JSON.stringify(resources))}
      if(Number.isFinite(s.dailyTarget)){dailyTarget=s.dailyTarget;localStorage.setItem(K.dailyTarget,JSON.stringify(dailyTarget))}
      if(typeof s.theme==="boolean")localStorage.setItem(K.theme,JSON.stringify(s.theme));
    }else{
      await bridgeCall("saveCloud",JSON.stringify(snapshot()));
    }
  }catch(e){}
}
function showLogin(){ $("#loginScreen")?.classList.remove("hidden"); }
function hideLogin(){ $("#loginScreen")?.classList.add("hidden"); }
function setProfile(){
  const pe=$("#profileEmail"), lb=$("#logoutBtn");
  if(currentUser){
    pe.textContent=currentUser.email||"Account sincronizzato";
    lb.innerHTML='<span>↪</span><div><b>Esci</b><small>Disconnetti questo account</small></div><i>›</i>';
  }else{
    pe.textContent="Modalità ospite · dati solo su questo dispositivo";
    lb.innerHTML='<span>↪</span><div><b>Accedi e sincronizza</b><small>Salva i progressi anche su altri dispositivi</small></div><i>›</i>';
  }
}

async function initAccount(){
  render();
  applyTheme();
  const guest=localStorage.getItem("ef_guest_mode")==="1";
  try{
    const r=await bridgeCall("authStatus");
    const u=r?.data?.user;
    if(u){
      currentUser=u;localStorage.removeItem("ef_guest_mode");hideLogin();updateSyncStatus("Online","online");
      await loadCloudState();cloudReady=true;setProfile();applyTheme();render();return;
    }
  }catch(e){}
  currentUser=null;cloudReady=false;setProfile();updateSyncStatus(navigator.onLine?"Locale":"Offline",navigator.onLine?null:"offline");
  if(guest)hideLogin();else showLogin();
}

(function setupLogin(){
  let step="email",resendTimer=null,remaining=0;
  const email=$("#loginEmail"),code=$("#loginCode"),codeWrap=$("#codeWrap"),
        btn=$("#loginBtn"),resend=$("#resendBtn"),back=$("#backEmailBtn"),msg=$("#loginMsg");

  function setMsg(t){msg.textContent=t}
  function startCooldown(){
    remaining=30;resend.disabled=true;resend.classList.remove("hidden");
    clearInterval(resendTimer);
    resendTimer=setInterval(()=>{
      remaining--;resend.textContent=remaining>0?`Invia di nuovo (${remaining}s)`:"Invia di nuovo il codice";
      if(remaining<=0){clearInterval(resendTimer);resend.disabled=false}
    },1000);
  }
  async function sendCode(){
    const e=email.value.trim();
    if(!e)return setMsg("Inserisci un indirizzo email.");
    btn.disabled=true;setMsg("Invio del codice in corso...");
    try{
      const r=await bridgeCall("startLogin",e);
      if(!r.ok)throw new Error(r?.data?.message||"Impossibile inviare il codice.");
      step="code";email.disabled=true;codeWrap.classList.remove("hidden");back.classList.remove("hidden");
      btn.textContent="Accedi";setMsg("Codice inviato. Controlla anche Spam e Promozioni.");code.focus();startCooldown();
    }catch(e){setMsg(e.message||"Impossibile inviare il codice.")}
    finally{btn.disabled=false}
  }
  btn.onclick=async()=>{
    if(step==="email")return sendCode();
    const e=email.value.trim(),c=code.value.trim();
    if(c.length!==6)return setMsg("Inserisci il codice a 6 cifre.");
    btn.disabled=true;setMsg("Verifica in corso...");
    try{
      const r=await bridgeCall("verifyCode",e,c);
      if(!r.ok)throw new Error(r?.data?.message||r?.data?.error||"Codice non valido.");
      const s=await bridgeCall("authStatus");
      const u=s?.data?.user;
      if(!u)throw new Error("Accesso non completato.");
      currentUser=u;localStorage.removeItem("ef_guest_mode");hideLogin();updateSyncStatus("Online","online");
      await loadCloudState();cloudReady=true;setProfile();applyTheme();render();toast("Accesso effettuato e sincronizzazione attiva.");
    }catch(e){setMsg(e.message||"Codice non valido.")}
    finally{btn.disabled=false}
  };
  resend.onclick=sendCode;
  back.onclick=()=>{
    step="email";email.disabled=false;codeWrap.classList.add("hidden");back.classList.add("hidden");resend.classList.add("hidden");
    btn.textContent="Invia codice";code.value="";setMsg("Accedendo puoi sincronizzare piano, progressi, errori e statistiche tra più dispositivi.");email.focus();
  };
  const guest=()=>{
    currentUser=null;cloudReady=false;localStorage.setItem("ef_guest_mode","1");hideLogin();setProfile();toast("Modalità ospite attiva.");
  };
  $("#guestBtn").onclick=guest;
  $("#guestClose").onclick=guest;

  $("#logoutBtn").onclick=async()=>{
    if(!currentUser){localStorage.removeItem("ef_guest_mode");showLogin();return}
    try{await bridgeCall("signOut")}catch(e){}
    currentUser=null;cloudReady=false;localStorage.removeItem("ef_guest_mode");setProfile();showLogin();
  };
})();






// Calendario mensile
let calendarCursor=new Date(),calendarSelected=nowDay();
function calendarEvents(dateStr){
  const items=[];
  exams.filter(e=>e.date===dateStr).forEach(e=>items.push({type:"exam",title:e.name,meta:"Esame"}));
  tasks.filter(t=>t.date===dateStr).forEach(t=>items.push({type:"task",title:t.text,meta:t.done?"Completata":"Checklist"}));
  plan?.schedule?.filter(s=>s.date===dateStr).forEach(s=>items.push({type:"study",title:s.type==="study"?`Studio ${s.from}-${s.to}`:"Ripasso",meta:plan.subject||"Piano"}));
  focusSessions.filter(s=>(s.date||"").slice(0,10)===dateStr).forEach(s=>items.push({type:"focus",title:s.topic||"Focus",meta:`${s.minutes||0} min`}));
  return items;
}
function renderCalendar(){
  const grid=$("#calendarGrid"),title=$("#calendarTitle"),details=$("#calendarDayDetails");if(!grid||!title||!details)return;
  const y=calendarCursor.getFullYear(),m=calendarCursor.getMonth();
  title.textContent=new Date(y,m,1).toLocaleDateString("it-IT",{month:"long",year:"numeric"});
  const first=new Date(y,m,1),offset=(first.getDay()+6)%7;
  const start=new Date(y,m,1-offset);
  grid.innerHTML="";
  for(let i=0;i<42;i++){
    const d=new Date(start);d.setDate(start.getDate()+i);
    const ds=localDay(d),events=calendarEvents(ds);
    const b=document.createElement("button");b.className="calendar-day"+(d.getMonth()!==m?" other":"")+(ds===nowDay()?" today":"")+(ds===calendarSelected?" selected":"");
    b.innerHTML=`<div class="calendar-num">${d.getDate()}</div><div class="calendar-dots">${events.slice(0,4).map(e=>`<span class="calendar-dot ${e.type}"></span>`).join("")}</div>`;
    b.onclick=()=>{calendarSelected=ds;renderCalendar()};
    grid.appendChild(b);
  }
  const ev=calendarEvents(calendarSelected);
  details.innerHTML=`<div class="eyebrow">${new Date(calendarSelected+"T00:00:00").toLocaleDateString("it-IT",{weekday:"long",day:"numeric",month:"long"})}</div>`+
    (ev.length?ev.map(e=>`<div class="calendar-detail"><b>${esc(e.title)}</b><small>${esc(e.meta)}</small></div>`).join(""):'<div class="empty-state">Nessuna attività programmata.</div>');
}
$("#calendarQuick")?.addEventListener("click",()=>{calendarCursor=new Date();calendarSelected=nowDay();$("#calendarSheet").classList.remove("hidden");renderCalendar()});
$("#calendarClose")?.addEventListener("click",()=>$("#calendarSheet").classList.add("hidden"));
$("#calendarPrev")?.addEventListener("click",()=>{calendarCursor.setMonth(calendarCursor.getMonth()-1);renderCalendar()});
$("#calendarNext")?.addEventListener("click",()=>{calendarCursor.setMonth(calendarCursor.getMonth()+1);renderCalendar()});
$("#calendarSheet")?.addEventListener("click",e=>{if(e.target===$("#calendarSheet"))$("#calendarSheet").classList.add("hidden")});

// Cronologia
let historyFilter="all";
function historyItems(){
  const out=[];
  focusSessions.forEach(s=>out.push({type:"focus",date:s.date,title:s.topic||"Sessione Focus",value:`${s.minutes||0} min`,icon:"◷"}));
  stats.forEach(s=>out.push({type:"quiz",date:s.date,title:`${s.subject||"Quiz"} · ${s.topic||""}`,value:`${s.pct||0}%`,icon:"✦"}));
  tasks.filter(t=>t.done).forEach(t=>out.push({type:"task",date:(t.date||nowDay())+"T12:00:00",title:t.text,value:"Fatto",icon:"✓"}));
  return out.sort((a,b)=>new Date(b.date)-new Date(a.date));
}
function renderHistory(){
  const el=$("#historyList");if(!el)return;
  const rows=historyItems().filter(x=>historyFilter==="all"||x.type===historyFilter).slice(0,100);
  if(!rows.length){el.innerHTML='<div class="empty-state">Nessuna attività registrata.</div>';return}
  el.innerHTML=rows.map(x=>`<div class="history-item"><div class="history-icon">${x.icon}</div><div><b>${esc(x.title)}</b><small>${new Date(x.date).toLocaleString("it-IT",{day:"numeric",month:"short",hour:"2-digit",minute:"2-digit"})}</small></div><div class="history-value">${esc(x.value)}</div></div>`).join("");
}
$("#historyQuick")?.addEventListener("click",()=>{$("#historySheet").classList.remove("hidden");renderHistory()});
$("#historyClose")?.addEventListener("click",()=>$("#historySheet").classList.add("hidden"));
$("#historySheet")?.addEventListener("click",e=>{if(e.target===$("#historySheet"))$("#historySheet").classList.add("hidden")});
$$(".history-seg").forEach(b=>b.onclick=()=>{$$(".history-seg").forEach(x=>x.classList.remove("active"));b.classList.add("active");historyFilter=b.dataset.history;renderHistory()});

// Obiettivo giornaliero
$("#dailyTargetBtn")?.addEventListener("click",()=>{
  const v=prompt("Quanti minuti vuoi studiare ogni giorno?",String(dailyTarget));
  if(v===null)return;
  const n=parseInt(v,10);
  if(!Number.isFinite(n)||n<10||n>720)return toast("Inserisci un valore tra 10 e 720 minuti.");
  dailyTarget=n;save(K.dailyTarget,dailyTarget);updateDailyTargetState();renderDailyScore();toast("Obiettivo giornaliero aggiornato.");
});

// Esami multipli
$("#examsQuick")?.addEventListener("click",()=>{$("#examsSheet").classList.remove("hidden");renderExams()});
$("#examsClose")?.addEventListener("click",()=>$("#examsSheet").classList.add("hidden"));
$("#examsSheet")?.addEventListener("click",e=>{if(e.target===$("#examsSheet"))$("#examsSheet").classList.add("hidden")});
$("#examAddBtn")?.addEventListener("click",()=>{
  const name=$("#examNameInput").value.trim(),date=$("#examDateInput").value;
  if(!name||!date)return toast("Inserisci nome e data dell'esame.");
  exams.push({id:"e_"+Date.now(),name,date,created:new Date().toISOString()});
  save(K.exams,exams);$("#examNameInput").value="";$("#examDateInput").value="";renderExams();toast("Esame aggiunto.");
});

// Ricerca globale
$("#searchQuick")?.addEventListener("click",()=>{$("#searchSheet").classList.remove("hidden");$("#globalSearchInput").focus();renderSearch("")});
$("#searchClose")?.addEventListener("click",()=>$("#searchSheet").classList.add("hidden"));
$("#searchSheet")?.addEventListener("click",e=>{if(e.target===$("#searchSheet"))$("#searchSheet").classList.add("hidden")});
$("#globalSearchInput")?.addEventListener("input",e=>renderSearch(e.target.value));

// Materiali
$("#resourcesQuick")?.addEventListener("click",()=>{$("#resourcesSheet").classList.remove("hidden");renderResources()});
$("#resourcesClose")?.addEventListener("click",()=>$("#resourcesSheet").classList.add("hidden"));
$("#resourcesSheet")?.addEventListener("click",e=>{if(e.target===$("#resourcesSheet"))$("#resourcesSheet").classList.add("hidden")});
$("#resourceAddBtn")?.addEventListener("click",()=>{
  const title=$("#resourceTitle").value.trim(),url=$("#resourceUrl").value.trim(),note=$("#resourceNote").value.trim();
  if(!title&&!url)return toast("Inserisci almeno un titolo o un link.");
  if(url && !/^https?:\/\//i.test(url))return toast("Il link deve iniziare con http:// o https://");
  resources.unshift({title:title||"Materiale",url,note,date:new Date().toISOString()});
  resources=resources.slice(0,200);save(K.resources,resources);
  $("#resourceTitle").value="";$("#resourceUrl").value="";$("#resourceNote").value="";
  renderResources();toast("Materiale salvato.");
});

// Appunti
const notesQuick=$("#notesQuick");
if(notesQuick)notesQuick.onclick=()=>{$("#notesSheet").classList.remove("hidden");renderNotes()};
$("#notesClose")?.addEventListener("click",()=>$("#notesSheet").classList.add("hidden"));
$("#notesSheet")?.addEventListener("click",e=>{if(e.target===$("#notesSheet"))$("#notesSheet").classList.add("hidden")});
$("#noteSaveBtn")?.addEventListener("click",()=>{
  const title=$("#noteTitle").value.trim(),body=$("#noteBody").value.trim();
  if(!title&&!body)return toast("Scrivi almeno un titolo o un contenuto.");
  notes.unshift({title:title||"Appunto",body,date:new Date().toISOString()});notes=notes.slice(0,300);
  save(K.notes,notes);$("#noteTitle").value="";$("#noteBody").value="";renderNotes();toast("Appunto salvato.");
});

// Checklist giornaliera
const tasksQuick=$("#tasksQuick");
if(tasksQuick)tasksQuick.onclick=()=>{$("#tasksSheet").classList.remove("hidden");renderTasks()};
$("#tasksClose")?.addEventListener("click",()=>$("#tasksSheet").classList.add("hidden"));
$("#tasksSheet")?.addEventListener("click",e=>{if(e.target===$("#tasksSheet"))$("#tasksSheet").classList.add("hidden")});
$("#taskAddBtn")?.addEventListener("click",()=>{
  const text=$("#taskInput").value.trim();if(!text)return toast("Inserisci un'attività.");
  tasks.push({text,done:false,date:nowDay()});save(K.tasks,tasks);$("#taskInput").value="";renderTasks();
});
$("#taskInput")?.addEventListener("keydown",e=>{if(e.key==="Enter")$("#taskAddBtn").click()});

// Ripasso flashcard in scadenza
$("#dueReviewBtn")?.addEventListener("click",()=>{
  $("#flashSheet").classList.remove("hidden");renderFlashcards();
});

// Obiettivo settimanale
const editGoalBtn=$("#editGoalBtn");
if(editGoalBtn)editGoalBtn.onclick=()=>{
  const v=prompt("Quanti minuti vuoi studiare ogni settimana?",String(weeklyGoal));
  if(v===null)return;
  const n=parseInt(v,10);
  if(!Number.isFinite(n)||n<30||n>5000)return toast("Inserisci un valore tra 30 e 5000 minuti.");
  weeklyGoal=n;save(K.goal,weeklyGoal);renderWeeklyGoal();toast("Obiettivo settimanale aggiornato.");
};

// Focus timer
let focusTotal=25*60,focusLeft=focusTotal,focusRunning=false,focusInterval=null;
function paintFocus(){
  const el=$("#focusTimer");if(!el)return;
  const m=Math.floor(focusLeft/60),s=focusLeft%60;el.textContent=`${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`;
  const b=$("#focusStart");if(b)b.textContent=focusRunning?"Pausa":focusLeft<focusTotal?"Riprendi":"Avvia";
}
function setFocusMinutes(min){
  clearInterval(focusInterval);focusRunning=false;focusTotal=min*60;focusLeft=focusTotal;paintFocus();
  $$(".focus-preset").forEach(x=>x.classList.toggle("active",+x.dataset.min===min));
}
function completeFocus(){
  focusRunning=false;clearInterval(focusInterval);focusLeft=0;paintFocus();
  const topic=$("#focusTopic")?.value.trim()||"Studio";
  const minutes=Math.round(focusTotal/60);
  focusSessions.unshift({date:new Date().toISOString(),minutes,topic});
  focusSessions=focusSessions.slice(0,500);save(K.focus,focusSessions);
  streak.xp=(streak.xp||0)+Math.max(5,Math.round(minutes/5));save(K.streak,streak);
  render();toast(`Sessione completata: ${minutes} min registrati.`);
}
const focusQuick=$("#focusQuick");
if(focusQuick)focusQuick.onclick=()=>{$("#focusSheet").classList.remove("hidden");paintFocus()};
const focusClose=$("#focusClose");
if(focusClose)focusClose.onclick=()=>$("#focusSheet").classList.add("hidden");
const focusReset=$("#focusReset");
if(focusReset)focusReset.onclick=()=>setFocusMinutes(Math.round(focusTotal/60));
const focusStart=$("#focusStart");
if(focusStart)focusStart.onclick=()=>{
  if(focusRunning){focusRunning=false;clearInterval(focusInterval);paintFocus();return}
  focusRunning=true;paintFocus();
  focusInterval=setInterval(()=>{focusLeft--;if(focusLeft<=0)completeFocus();else paintFocus()},1000);
};
$$(".focus-preset").forEach(b=>b.onclick=()=>setFocusMinutes(+b.dataset.min));
$("#focusSheet")?.addEventListener("click",e=>{if(e.target===$("#focusSheet"))$("#focusSheet").classList.add("hidden")});

// Flashcard
const flashQuick=$("#flashQuick");
if(flashQuick)flashQuick.onclick=()=>{$("#flashSheet").classList.remove("hidden");renderFlashcards()};
const flashClose=$("#flashClose");
if(flashClose)flashClose.onclick=()=>$("#flashSheet").classList.add("hidden");
$("#flashSheet")?.addEventListener("click",e=>{if(e.target===$("#flashSheet"))$("#flashSheet").classList.add("hidden")});
const flashAddBtn=$("#flashAddBtn");
if(flashAddBtn)flashAddBtn.onclick=()=>{
  const front=$("#flashFront").value.trim(),back=$("#flashBack").value.trim();
  if(!front||!back)return toast("Inserisci domanda e risposta.");
  flashcards.push({front,back,known:0,date:new Date().toISOString()});save(K.flash,flashcards);
  $("#flashFront").value="";$("#flashBack").value="";renderFlashcards();toast("Flashcard aggiunta.");
};

// Import backup
const importBtn=$("#importBtn");
if(importBtn)importBtn.onclick=()=>{
  const raw=prompt("Incolla qui il backup JSON di ExamFlow:");
  if(!raw)return;
  try{
    const d=JSON.parse(raw);
    if("plan" in d)plan=d.plan;
    if(Array.isArray(d.errors))errors=d.errors;
    if(Array.isArray(d.stats))stats=d.stats;
    if(d.streak)streak=d.streak;
    if(d.mastery&&typeof d.mastery==="object")mastery=d.mastery;
    if(Array.isArray(d.focusSessions))focusSessions=d.focusSessions;
    if(Number.isFinite(d.weeklyGoal))weeklyGoal=d.weeklyGoal;
    if(Array.isArray(d.flashcards))flashcards=d.flashcards;
    if(Array.isArray(d.notes))notes=d.notes;
    if(Array.isArray(d.tasks))tasks=d.tasks;
    if(Array.isArray(d.exams))exams=d.exams;
    if(Array.isArray(d.resources))resources=d.resources;
    if(Number.isFinite(d.dailyTarget))dailyTarget=d.dailyTarget;
    if(typeof d.theme==="boolean")localStorage.setItem(K.theme,JSON.stringify(d.theme));
    localStorage.setItem(K.plan,JSON.stringify(plan));localStorage.setItem(K.errors,JSON.stringify(errors));
    localStorage.setItem(K.stats,JSON.stringify(stats));localStorage.setItem(K.streak,JSON.stringify(streak));
    localStorage.setItem(K.mastery,JSON.stringify(mastery));localStorage.setItem(K.focus,JSON.stringify(focusSessions));
    localStorage.setItem(K.goal,JSON.stringify(weeklyGoal));localStorage.setItem(K.flash,JSON.stringify(flashcards));localStorage.setItem(K.notes,JSON.stringify(notes));localStorage.setItem(K.tasks,JSON.stringify(tasks));localStorage.setItem(K.exams,JSON.stringify(exams));localStorage.setItem(K.resources,JSON.stringify(resources));localStorage.setItem(K.dailyTarget,JSON.stringify(dailyTarget));
    if(cloudReady){clearTimeout(cloudTimer);cloudTimer=setTimeout(saveCloudState,700)}applyTheme();render();toast("Backup importato.");
  }catch(e){toast("Backup non valido.");}
};

function updateNotifState(){
  const enabled=load(K.notif,false),el=$("#notifState");if(el)el.textContent=enabled?"Attivi":"Disattivati";
}
const notifBtn=$("#notifBtn");
if(notifBtn)notifBtn.onclick=()=>{
  const next=!load(K.notif,false);save(K.notif,next);updateNotifState();
  try{if(window.AndroidBridge&&window.AndroidBridge.setStudyReminders)window.AndroidBridge.setStudyReminders(next)}catch(e){}
  toast(next?"Promemoria studio attivati.":"Promemoria studio disattivati.");
};
updateNotifState();

window.addEventListener("online",()=>{updateSyncStatus(currentUser?"Online":"Locale",currentUser?"online":null);if(currentUser&&cloudReady)saveCloudState()});
window.addEventListener("offline",()=>updateSyncStatus("Offline","offline"));
initAccount();
