package com.examflow.italia;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.SharedPreferences;

import org.json.JSONObject;
import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("examflow", MODE_PRIVATE);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setDatabaseEnabled(true);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void setGeminiKey(String key) {
            prefs.edit().putString("gemini_key", key == null ? "" : key.trim()).apply();
        }

        @JavascriptInterface
        public boolean hasGeminiKey() {
            return !prefs.getString("gemini_key", "").isEmpty();
        }

        @JavascriptInterface
        public void generateQuiz(String payload, String callbackId) {
            new Thread(() -> {
                boolean ok = false;
                String result;
                try {
                    String key = prefs.getString("gemini_key", "");
                    if (key.isEmpty()) throw new Exception("Imposta prima la chiave Gemini dal pulsante in alto.");

                    JSONObject in = new JSONObject(payload);
                    String subject = in.optString("subject");
                    String topic = in.optString("topic");
                    String difficulty = in.optString("difficulty", "media");
                    int count = Math.max(3, Math.min(10, in.optInt("count", 5)));

                    String prompt = "Crea " + count + " domande a scelta multipla in italiano per uno studente universitario.\\n"
                            + "Materia: " + subject + "\\nArgomento: " + topic + "\\nDifficoltà: " + difficulty + "\\n"
                            + "Restituisci SOLO JSON valido nel formato: "
                            + "{\\\"questions\\\":[{\\\"question\\\":\\\"...\\\",\\\"options\\\":[\\\"...\\\",\\\"...\\\",\\\"...\\\",\\\"...\\\"],\\\"correctIndex\\\":0,\\\"explanation\\\":\\\"...\\\"}]}. "
                            + "Ogni domanda deve avere esattamente 4 opzioni e una sola risposta corretta. Evita ambiguità.";

                    JSONObject body = new JSONObject();
                    JSONArray contents = new JSONArray();
                    JSONObject content = new JSONObject();
                    JSONArray parts = new JSONArray();
                    parts.put(new JSONObject().put("text", prompt));
                    content.put("parts", parts);
                    contents.put(content);
                    body.put("contents", contents);
                    body.put("generationConfig", new JSONObject().put("responseMimeType", "application/json"));

                    URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + key);
                    HttpURLConnection c = (HttpURLConnection) url.openConnection();
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(45000);
                    c.setRequestMethod("POST");
                    c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    c.setDoOutput(true);
                    byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                    try (OutputStream os = c.getOutputStream()) { os.write(bytes); }

                    int code = c.getResponseCode();
                    InputStream is = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);

                    if (code < 200 || code >= 300) throw new Exception("Gemini ha restituito errore " + code);

                    JSONObject response = new JSONObject(sb.toString());
                    String text = response.getJSONArray("candidates").getJSONObject(0)
                            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text");
                    text = text.replaceFirst("^```json\\\\s*", "").replaceFirst("```$", "").trim();
                    JSONObject quiz = new JSONObject(text);
                    result = quiz.toString();
                    ok = true;
                } catch (Exception e) {
                    try {
                        result = new JSONObject().put("error", e.getMessage() == null ? "Errore AI" : e.getMessage()).toString();
                    } catch (Exception ignored) {
                        result = "{\"error\":\"Errore AI\"}";
                    }
                }

                final boolean success = ok;
                final String data = result;
                runOnUiThread(() -> {
                    String js = "nativeCallback(" + JSONObject.quote(callbackId) + "," + success + "," + JSONObject.quote(data) + ")";
                    webView.evaluateJavascript(js, null);
                });
            }).start();
        }
    }
}
