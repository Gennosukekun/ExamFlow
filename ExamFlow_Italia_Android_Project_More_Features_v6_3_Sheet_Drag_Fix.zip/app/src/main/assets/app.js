const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const K={plan:"ef_plan",plans:"ef_plans",activePlan:"ef_active_plan",errors:"ef_errors",stats:"ef_stats",streak:"ef_streak",theme:"ef_theme",mastery:"ef_mastery",notif:"ef_notif",focus:"ef_focus_sessions",goal:"ef_weekly_goal",flash:"ef_flashcards",notes:"ef_notes",tasks:"ef_tasks",exams:"ef_exams",resources:"ef_resources",dailyTarget:"ef_daily_target",journal:"ef_journal",oral:"ef_oral_sessions",saved:"ef_saved_questions",mistakeTags:"ef_mistake_tags",confidence:"ef_confidence_logs"};
let plan=load(K.plan,null), studyPlans=load(K.plans,[]), activePlanId=load(K.activePlan,null), errors=load(K.errors,[]), stats=load(K.stats,[]), streak=load(K.streak,{days:[],xp:0}), mastery=load(K.mastery,{}), focusSessions=load(K.focus,[]), weeklyGoal=load(K.goal,300), flashcards=load(K.flash,[]), notes=load(K.notes,[]), tasks=load(K.tasks,[]), exams=load(K.exams,[]), resources=load(K.resources,[]), dailyTarget=load(K.dailyTarget,60), journal=load(K.journal,[]), oralSessions=load(K.oral,[]), savedQuestions=load(K.saved,[]), mistakeTags=load(K.mistakeTags,{}), confidenceLogs=load(K.confidence,[]);
let currentScreen="home", quizMode="practice", currentQuiz=null;

// Piani d’esame multipli: migra automaticamente il vecchio piano singolo.
if(!studyPlans.length&&plan){plan.id=plan.id||`exam-${Date.now()}`;studyPlans=[plan];activePlanId=plan.id;localStorage.setItem(K.plans,JSON.stringify(studyPlans));localStorage.setItem(K.activePlan,JSON.stringify(activePlanId))}
if(studyPlans.length){plan=studyPlans.find(p=>p.id===activePlanId)||studyPlans[0];activePlanId=plan.id}else plan=null;
function saveStudyPlans(){save(K.plans,studyPlans);save(K.activePlan,activePlanId);save(K.plan,plan)}
function setActiveStudyPlan(id){activePlanId=id;plan=studyPlans.find(p=>p.id===id)||null;saveStudyPlans();render()}

function load(k,d){try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}}
let cloudReady=false,cloudTimer=null,currentUser=null;
function save(k,v){localStorage.setItem(k,JSON.stringify(v));if(cloudReady){clearTimeout(cloudTimer);cloudTimer=setTimeout(saveCloudState,700)}}
function snapshot(){return {plan,studyPlans,activePlanId,errors,stats,streak,mastery,focusSessions,weeklyGoal,flashcards,notes,tasks,exams,resources,dailyTarget,journal,oralSessions,savedQuestions,mistakeTags,confidenceLogs,theme:load(K.theme,false),notif:load(K.notif,false)}}
function toast(t){const el=$("#toast");el.textContent=t;el.classList.remove("hidden");setTimeout(()=>el.classList.add("hidden"),2200)}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function d0(){let d=new Date();d.setHours(12,0,0,0);return d}
function dateOnly(s){return new Date(s+"T12:00:00")}
function iso(d){return d.toISOString().slice(0,10)}
function addDays(d,n){let x=new Date(d);x.setDate(x.getDate()+n);return x}
function localDay(d=new Date()){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`}

const dayLabels=["Dom","Lun","Mar","Mer","Gio","Ven","Sab"];
let selectedDays=new Set([1,2,3,4,5]);
dayLabels.forEach((x,i)=>{const b=document.createElement("button");b.className="day-pill"+(selectedDays.has(i)?" active":"");b.textContent=x;b.onclick=()=>{selectedDays.has(i)?selectedDays.delete(i):selectedDays.add(i);b.classList.toggle("active")};$("#days").appendChild(b)});

function go(screen){
  if(screen==="stats"){}
  currentScreen=screen;
  $$(".screen").forEach(x=>x.classList.toggle("active",x.dataset.screen===screen));
  $$(".nav").forEach(x=>x.classList.toggle("active",x.dataset.goto===screen));
  const sub={home:"Il tuo piano verso l’esame",plan:"Organizza ogni giornata",quiz:"Allenati con l’AI",review:"Trasforma gli errori in punti forti",stats:"Misura i tuoi progressi",profile:"Personalizza ExamFlow"}[screen];
  $("#topSubtitle").textContent=sub||"ExamFlow";
  window.scrollTo({top:0,behavior:"smooth"});
  render();
}
$$("[data-goto]").forEach(b=>b.onclick=()=>go(b.dataset.goto));
window.examflowBack=()=>{if(currentScreen!=="home"){go("home");return true}return false};

function applyTheme(){
  const dark=load(K.theme,false); document.body.classList.toggle("dark",dark);
}
function toggleTheme(){save(K.theme,!load(K.theme,false));applyTheme()}
$("#themeBtn").onclick=toggleTheme; $("#themeSetting").onclick=toggleTheme; applyTheme();

function buildPlan(){
  const subject=$("#subject").value.trim(), examDate=$("#examDate").value, total=+$("#totalUnits").value;
  if(!subject||!examDate||!total)return toast("Completa materia, data e quantità totale.");
  if(!selectedDays.size)return toast("Seleziona almeno un giorno.");
  const exam=dateOnly(examDate), today=d0(); if(exam<=today)return toast("La data dell’esame deve essere futura.");
  const available=[]; for(let d=new Date(today);d<exam;d=addDays(d,1)) if(selectedDays.has(d.getDay())) available.push(new Date(d));
  if(!available.length)return toast("Non ci sono giorni disponibili.");
  const reviewDays=Math.min(+$("#reviewDays").value||0,Math.max(0,available.length-1));
  const studyDays=available.slice(0,available.length-reviewDays), review=available.slice(available.length-reviewDays);
  if(!studyDays.length)return toast("Riduci i giorni finali di ripasso.");
  const topics=$("#syllabus").value.split(/\n|,/).map(x=>x.trim()).filter(Boolean);
  const base=Math.floor(total/studyDays.length), rem=total%studyDays.length; let cursor=1;
  const schedule=studyDays.map((d,i)=>{const amount=base+(i<rem?1:0),from=cursor,to=cursor+amount-1;cursor=to+1;const a=Math.floor(i*topics.length/studyDays.length),b=Math.floor((i+1)*topics.length/studyDays.length);return{id:`s-${i}-${iso(d)}`,date:iso(d),type:"study",amount,from,to,topics:topics.slice(a,Math.max(a+1,b)),done:false}});
  review.forEach((d,i)=>schedule.push({id:`r-${i}-${iso(d)}`,date:iso(d),type:"review",done:false}));
  plan={id:`exam-${Date.now()}`,subject,examDate,totalUnits:total,unitType:$("#unitType").value,hoursPerDay:+$("#hoursPerDay").value,reviewDays,selectedDays:[...selectedDays],topics,schedule};
  studyPlans.push(plan);activePlanId=plan.id;saveStudyPlans(); toast("Piano creato."); render(); go("home");
}
$("#createPlanBtn").onclick=buildPlan;
function resetPlanBuilder(){
  $("#subject").value="";
  $("#examDate").value="";
  $("#totalUnits").value="";
  $("#unitType").selectedIndex=0;
  $("#hoursPerDay").value="";
  $("#reviewDays").value="";
  $("#syllabus").value="";
  $("#priorityMode").selectedIndex=0;
  selectedDays.clear();
  $$("#days .day-pill").forEach(b=>b.classList.remove("active"));
}
function startNewStudyPlan(){plan=null;activePlanId=null;save(K.activePlan,null);resetPlanBuilder();render();go("plan")}
$("#newPlanBtn").onclick=startNewStudyPlan;
$("#addStudyPlanBtn").onclick=startNewStudyPlan;
$("#printBtn").onclick=()=>window.print();

function progressPct(){
  if(!plan?.schedule?.length)return 0;
  return Math.round(100*plan.schedule.filter(x=>x.done).length/plan.schedule.length);
}
function daysLeft(){return plan?Math.max(0,Math.ceil((dateOnly(plan.examDate)-d0())/86400000)):0}
function streakCount(){
  let n=0,d=new Date();for(;;){if((streak.days||[]).includes(localDay(d))){n++;d.setDate(d.getDate()-1)}else break}return n
}
function readiness(){
  const recent=stats.slice(0,10),avg=recent.length?recent.reduce((a,b)=>a+b.pct,0)/recent.length:0,p=progressPct(),vol=Math.min(100,recent.length*10);
  return Math.round(avg*.65+p*.25+vol*.10)
}

function topicMastery(name){
  const m=mastery[name]||{correct:0,wrong:0,streak:0};
  const total=m.correct+m.wrong;
  if(!total)return 0;
  return Math.max(0,Math.min(100,Math.round((m.correct/total)*70 + Math.min(30,m.streak*10))));
}
function masteryLabel(v){
  if(v>=80)return "Consolidato";
  if(v>=60)return "Buono";
  if(v>=35)return "Da rinforzare";
  return "In apprendimento";
}
function updateMastery(topic,ok){
  if(!topic)return;
  const m=mastery[topic]||{correct:0,wrong:0,streak:0};
  if(ok){m.correct++;m.streak=(m.streak||0)+1}else{m.wrong++;m.streak=0}
  mastery[topic]=m;save(K.mastery,mastery);
}
function renderMastery(){
  const home=$("#masteryHome"), list=$("#masteryList");
  const topics=plan?.topics?.length?plan.topics:Object.keys(mastery);
  const rows=[...new Set(topics)].slice(0,30).map(t=>({t,v:topicMastery(t)})).sort((a,b)=>a.v-b.v);
  if(home){
    if(!rows.length)home.innerHTML='<div class="empty-state">Completa qualche quiz per vedere la padronanza degli argomenti.</div>';
    else home.innerHTML=rows.slice(0,4).map(x=>`<div class="mastery-row"><div><div class="label">${esc(x.t)}</div><div class="mastery-bar"><span style="width:${x.v}%"></span></div><div class="meta">${x.v}%</div></div><span class="mastery-badge">${masteryLabel(x.v)}</span></div>`).join("");
  }
  if(list){
    list.innerHTML=rows.length?rows.map(x=>`<div class="mastery-item"><b>${esc(x.t)}</b><small>${masteryLabel(x.v)} · ${x.v}%</small><div class="mastery-bar"><span style="width:${x.v}%"></span></div></div>`).join(""):'<div class="empty-state">Nessun dato di padronanza disponibile.</div>';
  }
}
function rebalancePlan(){
  if(!plan?.schedule?.length)return;
  const today=iso(d0());
  const weakTopics=(plan.topics||[]).map(t=>({t,v:topicMastery(t)})).sort((a,b)=>a.v-b.v).slice(0,Math.max(1,Math.ceil((plan.topics||[]).length/3))).map(x=>x.t);
  const future=plan.schedule.filter(x=>x.type==="study"&&!x.done&&x.date>=today);
  if(!future.length)return;
  future.forEach((x,i)=>{
    const weak=weakTopics.filter(t=>(x.topics||[]).includes(t));
    x.priority=weak.length?"high":"normal";
  });
}


function startOfWeek(){
  const d=new Date();d.setHours(0,0,0,0);
  const day=(d.getDay()+6)%7;d.setDate(d.getDate()-day);return d;
}
function weekFocusMinutes(){
  const start=startOfWeek().getTime();
  return focusSessions.filter(s=>new Date(s.date).getTime()>=start).reduce((n,s)=>n+(s.minutes||0),0);
}
function renderWeeklyGoal(){
  const mins=weekFocusMinutes(), pct=Math.min(100,Math.round(mins/Math.max(1,weeklyGoal)*100));
  const t=$("#weeklyGoalText"),b=$("#weeklyGoalBar");
  if(t)t.textContent=`${mins} / ${weeklyGoal} min`;
  if(b)b.style.width=pct+"%";
  const wm=$("#weekMinutes"),ts=$("#totalSessions");
  if(wm)wm.textContent=mins;if(ts)ts.textContent=focusSessions.length;
}
function renderFlashcards(){
  const area=$("#flashCardArea");if(!area)return;
  if(!flashcards.length){area.innerHTML='<div class="flash-empty">Nessuna flashcard. Creane una qui sotto oppure trasformane una dai tuoi appunti.</div>';return}
  const due=dueFlashcards();const f=due[0]||flashcards[0];
  area.innerHTML=`<div class="flashcard" id="activeFlash"><div class="front">${esc(f.front)}</div><div class="back">${esc(f.back)}</div></div><div class="flash-controls"><button id="flashAgain" class="secondary-btn">Da rivedere</button><button id="flashKnown" class="primary-btn">La so</button></div><p class="muted tiny">${flashcards.length} flashcard disponibili · Tocca la carta per girarla</p>`;
  $("#activeFlash").onclick=()=>$("#activeFlash").classList.toggle("flipped");
  $("#flashAgain").onclick=()=>{scheduleFlashcard(f,"again");save(K.flash,flashcards);renderFlashcards();renderDueReview()};
  $("#flashKnown").onclick=()=>{f.known=(f.known||0)+1;scheduleFlashcard(f,"good");save(K.flash,flashcards);renderFlashcards();renderDueReview();toast(f.stage>=5?"Flashcard molto ben consolidata.":"Prossimo ripasso programmato.")};
}


function nowDay(){return localDay(new Date())}
function scheduleFlashcard(card,quality){
  const today=new Date();
  const stage=card.stage||0;
  let days=1;
  if(quality==="good") days=[1,3,7,14,30,60][Math.min(stage,5)];
  if(quality==="again") days=1;
  card.stage=quality==="good"?Math.min(stage+1,5):0;
  const due=new Date(today);due.setDate(due.getDate()+days);
  card.due=localDay(due);
  return card;
}
function dueFlashcards(){
  const today=nowDay();
  return flashcards.filter(f=>!f.due||f.due<=today);
}
function renderDueReview(){
  const due=dueFlashcards();
  const t=$("#dueReviewText");
  if(t)t.textContent=due.length?`${due.length} flashcard da ripassare oggi`:"Nessuna flashcard in scadenza";
}
function renderNotes(){
  const el=$("#notesList");if(!el)return;
  if(!notes.length){el.innerHTML='<div class="empty-state">Nessun appunto salvato.</div>';return}
  el.innerHTML=notes.map((n,i)=>`<div class="note-item"><h4>${esc(n.title||"Appunto")}</h4><p>${esc(n.body||"")}</p><div class="note-actions"><button data-note-edit="${i}">Modifica</button><button data-note-delete="${i}">Elimina</button></div></div>`).join("");
  $$("[data-note-edit]").forEach(b=>b.onclick=()=>{
    const i=+b.dataset.noteEdit,n=notes[i];$("#noteTitle").value=n.title||"";$("#noteBody").value=n.body||"";
    notes.splice(i,1);save(K.notes,notes);renderNotes();
  });
  $$("[data-note-delete]").forEach(b=>b.onclick=()=>{notes.splice(+b.dataset.noteDelete,1);save(K.notes,notes);renderNotes();toast("Appunto eliminato.")});
}
function cleanOldTasks(){
  const today=nowDay();
  tasks=tasks.filter(t=>t.date===today || !t.done);
}
function renderTasks(){
  cleanOldTasks();
  const el=$("#tasksList");if(!el)return;
  if(!tasks.length){el.innerHTML='<div class="empty-state">Nessun obiettivo per oggi.</div>';return}
  el.innerHTML=tasks.map((t,i)=>`<div class="task-item ${t.done?"done":""}"><input type="checkbox" data-task-check="${i}" ${t.done?"checked":""}><span>${esc(t.text)}</span><button class="delete-task" data-task-delete="${i}">×</button></div>`).join("");
  $$("[data-task-check]").forEach(c=>c.onchange=()=>{tasks[+c.dataset.taskCheck].done=c.checked;save(K.tasks,tasks);renderTasks();renderAchievements()});
  $$("[data-task-delete]").forEach(b=>b.onclick=()=>{tasks.splice(+b.dataset.taskDelete,1);save(K.tasks,tasks);renderTasks()});
}
function renderAchievements(){
  const el=$("#achievementsGrid");if(!el)return;
  const completedTasks=tasks.filter(t=>t.done).length;
  const completedSessions=focusSessions.length;
  const quizCount=stats.length;
  const mastered=Object.keys(mastery).filter(k=>topicMastery(k)>=80).length;
  const data=[
    {icon:"🔥",name:"Costanza",desc:"Streak di 7 giorni",ok:streakCount()>=7},
    {icon:"🎯",name:"Quiz Master",desc:"10 quiz completati",ok:quizCount>=10},
    {icon:"🧠",name:"Memoria forte",desc:"5 argomenti consolidati",ok:mastered>=5},
    {icon:"⏱",name:"Focus",desc:"10 sessioni completate",ok:completedSessions>=10},
    {icon:"✅",name:"Organizzato",desc:"5 attività completate",ok:completedTasks>=5},
    {icon:"⚡",name:"100 XP",desc:"Raggiungi 100 XP",ok:(streak.xp||0)>=100}
  ];
  el.innerHTML=data.map(a=>`<div class="achievement ${a.ok?"":"locked"}"><div class="icon">${a.icon}</div><b>${a.name}</b><small>${a.ok?"Sbloccato":a.desc}</small></div>`).join("");
}


function daysUntil(dateStr){
  if(!dateStr)return 0;
  const today=new Date();today.setHours(0,0,0,0);
  const d=new Date(dateStr+"T00:00:00");
  return Math.ceil((d-today)/86400000);
}
function renderExams(){
  exams=exams.filter(x=>x&&x.name&&x.date);
  exams.sort((a,b)=>a.date.localeCompare(b.date));
  const list=$("#examsList"), statsEl=$("#examStatsList");
  const row=x=>{
    const d=daysUntil(x.date),label=d<0?`${Math.abs(d)} giorni fa`:d===0?"Oggi":`${d} giorni`;
    return `<div class="exam-item"><div><b>${esc(x.name)}</b><small>${new Date(x.date+"T00:00:00").toLocaleDateString("it-IT")} · ${label}</small></div><div class="exam-days">${d>=0?d:"✓"}</div><div class="exam-actions"><button data-exam-plan="${x.id}">Usa nel piano</button><button data-exam-del="${x.id}">Elimina</button></div></div>`;
  };
  if(list){
    list.innerHTML=exams.length?exams.map(row).join(""):'<div class="empty-state">Nessun esame salvato.</div>';
    $$("[data-exam-del]").forEach(b=>b.onclick=()=>{exams=exams.filter(x=>x.id!==b.dataset.examDel);save(K.exams,exams);renderExams();toast("Esame eliminato.")});
    $$("[data-exam-plan]").forEach(b=>b.onclick=()=>{
      const x=exams.find(e=>e.id===b.dataset.examPlan);if(!x)return;
      $("#subject").value=x.name;$("#examDate").value=x.date;$("#examsSheet").classList.add("hidden");go("plan");toast("Esame caricato nel piano.");
    });
  }
  if(statsEl){
    const upcoming=exams.filter(x=>daysUntil(x.date)>=0).slice(0,4);
    statsEl.innerHTML=upcoming.length?upcoming.map(x=>`<div class="exam-stat"><b>${esc(x.name)}</b><small>${daysUntil(x.date)===0?"Oggi":daysUntil(x.date)+" giorni"} · ${new Date(x.date+"T00:00:00").toLocaleDateString("it-IT")}</small></div>`).join(""):'<div class="empty-state">Aggiungi un esame per vedere il conto alla rovescia.</div>';
  }
}
function renderResources(){
  const el=$("#resourcesList");if(!el)return;
  if(!resources.length){el.innerHTML='<div class="empty-state">Nessun materiale salvato.</div>';return}
  el.innerHTML=resources.map((r,i)=>`<div class="resource-item"><b>${esc(r.title||"Materiale")}</b>${r.url?`<small class="resource-url">${esc(r.url)}</small>`:""}${r.note?`<p>${esc(r.note)}</p>`:""}<div class="resource-actions">${r.url?`<button data-res-open="${i}">Apri</button>`:""}<button data-res-del="${i}">Elimina</button></div></div>`).join("");
  $$("[data-res-open]").forEach(b=>b.onclick=()=>{
    const r=resources[+b.dataset.resOpen];if(r?.url){try{location.href=r.url}catch(e){toast("Impossibile aprire il link.")}}
  });
  $$("[data-res-del]").forEach(b=>b.onclick=()=>{resources.splice(+b.dataset.resDel,1);save(K.resources,resources);renderResources()});
}
function searchAll(q){
  const query=(q||"").trim().toLowerCase();
  if(!query)return [];
  const out=[];
  notes.forEach(n=>{if(`${n.title} ${n.body}`.toLowerCase().includes(query))out.push({kind:"Appunto",title:n.title||"Appunto",text:n.body||""})});
  tasks.forEach(t=>{if((t.text||"").toLowerCase().includes(query))out.push({kind:"Checklist",title:t.text,text:t.done?"Completata":"Da fare"})});
  flashcards.forEach(f=>{if(`${f.front} ${f.back}`.toLowerCase().includes(query))out.push({kind:"Flashcard",title:f.front,text:f.back})});
  resources.forEach(r=>{if(`${r.title} ${r.note} ${r.url}`.toLowerCase().includes(query))out.push({kind:"Materiale",title:r.title||"Materiale",text:r.note||r.url||""})});
  exams.forEach(e=>{if((e.name||"").toLowerCase().includes(query))out.push({kind:"Esame",title:e.name,text:e.date})});
  return out.slice(0,50);
}
function renderSearch(q=""){
  const el=$("#globalSearchResults");if(!el)return;
  const results=searchAll(q);
  if(!q.trim()){el.innerHTML='<div class="search-empty">Scrivi qualcosa per cercare in appunti, checklist, flashcard, materiali ed esami.</div>';return}
  if(!results.length){el.innerHTML='<div class="search-empty">Nessun risultato.</div>';return}
  el.innerHTML=results.map(r=>`<div class="search-result"><div class="kind">${esc(r.kind)}</div><b>${esc(r.title)}</b><small>${esc(r.text)}</small></div>`).join("");
}
function renderDailyScore(){
  const today=nowDay();
  const todayTasks=tasks.filter(t=>t.date===today);
  const taskScore=todayTasks.length?todayTasks.filter(t=>t.done).length/todayTasks.length:0;
  const todayFocus=focusSessions.filter(s=>(s.date||"").slice(0,10)===today).reduce((n,s)=>n+(s.minutes||0),0);
  const focusScore=Math.min(1,todayFocus/Math.max(1,dailyTarget));
  const todayQuiz=stats.filter(s=>(s.date||"").slice(0,10)===today).length;
  const quizScore=Math.min(1,todayQuiz/2);
  const score=Math.round((taskScore*.4+focusScore*.35+quizScore*.25)*100);
  const ring=$("#dailyScoreRing"),val=$("#dailyScoreValue"),title=$("#dailyScoreTitle"),meta=$("#dailyScoreMeta");
  if(ring)ring.style.setProperty("--score",score);
  if(val)val.textContent=score+"%";
  if(title)title.textContent=score>=80?"Giornata molto produttiva":score>=50?"Buon ritmo":score>0?"Continua così":"Inizia con un piccolo obiettivo";
  if(meta)meta.textContent=`${todayFocus} min focus · ${todayTasks.filter(t=>t.done).length}/${todayTasks.length} attività · ${todayQuiz} quiz`;
}


function nearestExam(){
  return exams.filter(e=>daysUntil(e.date)>=0).sort((a,b)=>a.date.localeCompare(b.date))[0]||null;
}
function weakestTopic(){
  const topics=[...new Set([...(plan?.topics||[]),...Object.keys(mastery)])];
  return topics.map(t=>({t,v:topicMastery(t)})).sort((a,b)=>a.v-b.v)[0]||null;
}
function renderSmartSuggestion(){
  const title=$("#smartSuggestionTitle"),text=$("#smartSuggestionText"),btn=$("#smartSuggestionBtn");
  if(!title||!text||!btn)return;
  const today=nowDay();
  const pendingTasks=tasks.filter(t=>t.date===today&&!t.done);
  const due=dueFlashcards();
  const weak=weakestTopic();
  const exam=nearestExam();

  if(pendingTasks.length){
    title.textContent=`Completa ${pendingTasks.length} attività di oggi`;
    text.textContent=pendingTasks[0].text;
    btn.textContent="Checklist";btn.onclick=()=>{$("#tasksSheet").classList.remove("hidden");renderTasks()};return;
  }
  if(due.length){
    title.textContent=`Hai ${due.length} flashcard da ripassare`;
    text.textContent="Un breve ripasso ora aiuta a mantenere le informazioni nel tempo.";
    btn.textContent="Ripassa";btn.onclick=()=>{$("#flashSheet").classList.remove("hidden");renderFlashcards()};return;
  }
  if(weak && weak.v<70){
    title.textContent=`Rinforza: ${weak.t}`;
    text.textContent=`Padronanza attuale ${weak.v}%. Un quiz breve può aiutarti a consolidare l'argomento.`;
    btn.textContent="Quiz";btn.onclick=()=>{$("#aiSubject").value=plan?.subject||"";$("#aiTopic").value=weak.t;go("quiz")};return;
  }
  if(exam){
    const d=daysUntil(exam.date);
    title.textContent=d===0?`${exam.name}: oggi`:`${exam.name}: ${d} giorni`;
    text.textContent="Mantieni il ritmo con una sessione Focus o un ripasso mirato.";
    btn.textContent="Focus";btn.onclick=()=>{$("#focusSheet").classList.remove("hidden");paintFocus()};return;
  }
  title.textContent="Configura il tuo primo obiettivo";
  text.textContent="Aggiungi un esame o crea un piano per ricevere suggerimenti personalizzati.";
  btn.textContent="Piano";btn.onclick=()=>go("plan");
}
function todayStudyMinutes(){
  const today=nowDay();
  return focusSessions.filter(s=>(s.date||"").slice(0,10)===today).reduce((n,s)=>n+(s.minutes||0),0);
}
function updateDailyTargetState(){
  const el=$("#dailyTargetState");if(el)el.textContent=`${dailyTarget} min al giorno`;
}
function updateSyncStatus(text,mode){
  const el=$("#syncStatus");if(!el)return;
  el.textContent=text;el.classList.remove("online","offline");
  if(mode)el.classList.add(mode);
}

function renderHome(){
  rebalancePlan();
  $("#homeSubject").textContent=plan?.subject||"Nessun esame attivo";
  $("#homeExamMeta").textContent=plan?`${dateOnly(plan.examDate).toLocaleDateString("it-IT")} · ${daysLeft()} giorni rimasti`:"Crea un piano per iniziare.";
  const p=progressPct();$("#ringValue").textContent=p+"%";$("#progressRing").style.setProperty("--p",p);
  $("#daysMetric").textContent=daysLeft();$("#streakMetric").textContent=streakCount();$("#xpMetric").textContent=streak.xp||0;
  const c=$("#todayCard");
  if(!plan){c.className="card empty-state";c.textContent="Crea un piano per vedere l’obiettivo di oggi.";return}
  const t=iso(d0()), x=plan.schedule.find(x=>x.date===t&&!x.done)||plan.schedule.find(x=>x.date>=t&&!x.done);
  if(!x){c.className="card empty-state";c.textContent="Piano completato. Ottimo lavoro.";return}
  const d=dateOnly(x.date);c.className="card";const priorityNote=x.priority==="high"?'<div class="plan-alert">Priorità alta: questo blocco contiene argomenti deboli.</div>':"";c.innerHTML=`<div class="eyebrow">${d.toLocaleDateString("it-IT",{weekday:"long",day:"numeric",month:"long"})}</div><h3>${x.type==="study"?`Studia ${x.amount} ${esc(plan.unitType)}`:"Giornata di ripasso"}</h3><p class="muted">${x.type==="study"?`${x.from}–${x.to}${x.topics?.length?` · ${x.topics.map(esc).join(", ")}`:""}`:"Concentrati sugli errori e sugli argomenti deboli."}</p>${priorityNote}<button id="todayStart" class="primary-btn">Inizia ora</button>`;
  $("#todayStart").onclick=()=>{if(x.type==="study"){$("#aiSubject").value=plan.subject;$("#aiTopic").value=x.topics?.join(", ")||`${plan.unitType} ${x.from}-${x.to}`;go("quiz")}else go("review")}
}
function renderPlan(){
  const plansBox=$("#studyPlans"),plansList=$("#studyPlansList");
  if(plansBox&&plansList){plansBox.classList.toggle("hidden",!studyPlans.length);plansList.innerHTML="";studyPlans.slice().sort((a,b)=>a.examDate.localeCompare(b.examDate)).forEach(p=>{const row=document.createElement("div");row.className="study-plan-row";const pct=p.schedule?.length?Math.round(100*p.schedule.filter(x=>x.done).length/p.schedule.length):0;row.innerHTML=`<div><b>${esc(p.subject)}</b><small>${dateOnly(p.examDate).toLocaleDateString("it-IT")} · ${pct}%${p.id===activePlanId?" · Attivo":""}</small></div><div><button class="small-btn open-study-plan">Apri</button><button class="small-btn delete-study-plan">×</button></div>`;row.querySelector(".open-study-plan").onclick=()=>setActiveStudyPlan(p.id);row.querySelector(".delete-study-plan").onclick=()=>{if(!confirm(`Eliminare il piano ${p.subject}?`))return;studyPlans=studyPlans.filter(x=>x.id!==p.id);if(activePlanId===p.id){plan=studyPlans[0]||null;activePlanId=plan?.id||null}saveStudyPlans();render()};plansList.appendChild(row)})}
  $("#planBuilder").classList.toggle("hidden",!!plan);$("#planActive").classList.toggle("hidden",!plan);
  if(!plan)return;
  const p=progressPct();$("#planSummaryTitle").textContent=plan.subject;$("#planSummaryMeta").textContent=`Esame ${dateOnly(plan.examDate).toLocaleDateString("it-IT")} · ${p}% completato`;$("#planPct").textContent=p+"%";$(".mini-ring").style.setProperty("--p",p);
  const el=$("#schedule");el.innerHTML="";
  plan.schedule.forEach((x,i)=>{const d=dateOnly(x.date),m=d.toLocaleDateString("it-IT",{month:"short"}).replace(".","");const row=document.createElement("div");row.className="timeline-item"+(x.done?" done":"");row.innerHTML=`<div class="date-badge"><div>${d.getDate()}<br><small>${m.toUpperCase()}</small></div></div><div><b>${x.type==="study"?`${x.amount} ${esc(plan.unitType)} · ${x.from}-${x.to}`:"Ripasso finale"}</b><div class="muted tiny">${x.type==="study"?(x.topics?.map(esc).join(" · ")||"Sessione di studio"):"Errori, quiz e simulazione"}</div></div><input type="checkbox" ${x.done?"checked":""}>`;row.querySelector("input").onchange=e=>{plan.schedule[i].done=e.target.checked;saveStudyPlans();render()};el.appendChild(row)})
}
$("#lateBtn").onclick=()=>{if(!plan)return;const today=iso(d0()),missed=plan.schedule.filter(x=>x.type==="study"&&!x.done&&x.date<today).reduce((s,x)=>s+x.amount,0),future=plan.schedule.filter(x=>x.type==="study"&&!x.done&&x.date>=today);if(!missed)return toast("Non risultano unità arretrate.");if(!future.length)return toast("Nessun giorno futuro disponibile.");const total=future.reduce((s,x)=>s+x.amount,0)+missed,base=Math.floor(total/future.length),rem=total%future.length;let start=plan.schedule.filter(x=>x.type==="study"&&x.done).reduce((s,x)=>s+x.amount,0)+1;plan.schedule=plan.schedule.filter(x=>!(x.type==="study"&&!x.done&&x.date<today));plan.schedule.filter(x=>x.type==="study"&&!x.done).forEach((x,i)=>{x.amount=base+(i<rem?1:0);x.from=start;x.to=start+x.amount-1;start=x.to+1});saveStudyPlans();render();toast("Piano ricalcolato.")};

$$(".seg").forEach(b=>b.onclick=()=>{$$(".seg").forEach(x=>x.classList.remove("active"));b.classList.add("active");quizMode=b.dataset.mode;$("#examTimeWrap")?.classList.toggle("hidden",quizMode!=="exam");if(quizMode==="adaptive"){const a=stats.slice(0,8),avg=a.length?a.reduce((s,x)=>s+x.pct,0)/a.length:60;$("#aiDifficulty").value=avg>=80?"difficile":avg>=60?"media":"facile";toast("Difficoltà adattata ai tuoi risultati.")}});
async function nativeGenerateQuiz(payload){
  if(!currentUser) throw new Error("Accedi per usare i Quiz AI.");
  const r=await bridgeCall("generateQuiz",JSON.stringify(payload));
  if(!r.ok) throw new Error(r?.data?.error||r?.data?.message||"Errore nella generazione del quiz.");
  return r.data;
}
$("#generateQuizBtn").onclick=async()=>{const subject=$("#aiSubject").value.trim(),topic=$("#aiTopic").value.trim();if(!subject||!topic)return toast("Inserisci materia e argomento.");$("#quizStatus").textContent="Genero il quiz...";$("#generateQuizBtn").disabled=true;try{const d=await nativeGenerateQuiz({subject,topic,difficulty:$("#aiDifficulty").value,count:+$("#aiCount").value,type:$("#aiType")?.value||"mixed"});startQuiz(d.questions,{subject,topic,type:$("#aiType")?.value||"mixed"})}catch(e){$("#quizStatus").textContent=e.message}finally{$("#generateQuizBtn").disabled=false}};
function startQuiz(qs,meta){currentQuiz={questions:qs,answers:Array(qs.length).fill(null),meta,startedAt:Date.now()};$("#quizArea").innerHTML="";if(quizMode==="exam"){const mins=Math.max(1,+$("#examMinutes").value||20),timer=document.createElement("div");timer.className="card exam-timer";timer.innerHTML=`<b id="examTimer">${mins}:00</b><span> tempo simulazione</span>`;$("#quizArea").appendChild(timer);let left=mins*60;currentQuiz.timer=setInterval(()=>{left--;const el=$("#examTimer");if(el)el.textContent=`${Math.floor(left/60)}:${String(left%60).padStart(2,"0")}`;if(left<=0){clearInterval(currentQuiz.timer);currentQuiz.timer=null;currentQuiz.questions.forEach((q,i)=>{if(currentQuiz.answers[i]===null)currentQuiz.answers[i]=false});finishQuiz();toast("Tempo terminato.")}},1000)}qs.forEach((q,i)=>{const c=document.createElement("div");c.className="card question";c.innerHTML=`<div class="question-head"><h3>${i+1}. ${esc(q.question)}</h3><button class="save-q" title="Salva domanda">☆</button></div><div class="options"></div>`;c.querySelector(".save-q").onclick=()=>toggleSavedQuestion(q,currentQuiz.meta,c.querySelector(".save-q"));q.options.forEach((o,j)=>{const b=document.createElement("button");b.className="option";b.textContent=o;b.onclick=()=>answerQuiz(i,j,c,b);c.querySelector(".options").appendChild(b)});$("#quizArea").appendChild(c)});$("#quizStatus").textContent=`${qs.length} domande pronte.`}
function answerQuiz(i,j,c,b){if(currentQuiz.answers[i]!==null)return;const q=currentQuiz.questions[i],ok=j===q.correctIndex;currentQuiz.answers[i]=ok;c.querySelectorAll(".option").forEach((x,k)=>{x.disabled=true;if(k===q.correctIndex)x.classList.add("correct")});updateMastery(currentQuiz.meta.topic,ok);if(!ok){b.classList.add("wrong");errors.unshift({q:q.question,a:q.options[q.correctIndex],explanation:q.explanation||"",subject:currentQuiz.meta.subject,topic:currentQuiz.meta.topic,date:new Date().toISOString(),masteredCount:0});save(K.errors,errors.slice(0,200))}const p=document.createElement("p");p.className="muted";p.textContent=(ok?"Corretto. ":"Da ripassare. ")+(q.explanation||"");c.appendChild(p);if(currentQuiz.answers.every(x=>x!==null))finishQuiz()}
function finishQuiz(){if(currentQuiz.timer){clearInterval(currentQuiz.timer);currentQuiz.timer=null}const total=currentQuiz.answers.length,correct=currentQuiz.answers.filter(Boolean).length,pct=Math.round(correct/total*100);stats.unshift({subject:currentQuiz.meta.subject,topic:currentQuiz.meta.topic,correct,total,pct,date:new Date().toISOString(),mode:quizMode,durationSec:Math.round((Date.now()-currentQuiz.startedAt)/1000)});stats=stats.slice(0,100);save(K.stats,stats);const today=localDay();if(!(streak.days||[]).includes(today)){streak.days=(streak.days||[]).concat(today).slice(-365);streak.xp=(streak.xp||0)+10;save(K.streak,streak)}const r=document.createElement("div");r.className="card quiz-result";r.innerHTML=`<b>${pct}%</b><h3>${pct>=80?"Ottima preparazione":pct>=60?"Buona base":"Da rinforzare"}</h3><p>${correct}/${total} corrette</p>`;$("#quizArea").appendChild(r);render()}
$("#smartReviewBtn").onclick=()=>{if(!errors.length)return toast("Non hai errori da ripassare.");$("#aiSubject").value=errors.find(x=>x.subject)?.subject||"Ripasso";$("#aiTopic").value=[...new Set(errors.slice(0,10).map(x=>x.topic).filter(Boolean))].join(", ")||errors.slice(0,4).map(x=>x.q).join(" · ");go("quiz")};

function renderReview(){
  $("#errorMetric").textContent=errors.length;$("#weakMetric").textContent=new Set(errors.map(x=>x.topic).filter(Boolean)).size;$("#noErrors").classList.toggle("hidden",errors.length>0);const el=$("#errorsList");el.innerHTML="";
  errors.slice(0,50).forEach((e,i)=>{const c=document.createElement("div");c.className="card error-card";c.innerHTML=`<div class="tag">${esc(e.subject||"Ripasso")}</div><b>${esc(e.q)}</b><p>Risposta: ${esc(e.a)}</p>${e.explanation?`<p>${esc(e.explanation)}</p>`:""}<button>Padroneggiato</button>`;c.querySelector("button").onclick=()=>{e.masteredCount=(e.masteredCount||0)+1;if(e.masteredCount>=2){errors.splice(i,1);toast("Errore consolidato e rimosso.")}else{errors[i]=e;toast("Conferma ancora una volta dopo un altro ripasso.")}save(K.errors,errors);render()};el.appendChild(c)})
}
function renderStats(){
  const recent=stats.slice(0,10),avg=recent.length?Math.round(recent.reduce((a,b)=>a+b.pct,0)/recent.length):0;$("#avgStat").textContent=avg+"%";$("#readyStat").textContent=readiness()+"%";$("#statsStreak").textContent=streakCount();$("#statsXp").textContent=streak.xp||0;$("#statsLevel").textContent=Math.floor((streak.xp||0)/100)+1;
  const ch=$("#chart");ch.innerHTML="";(recent.length?recent.slice().reverse():[0,0,0,0,0]).forEach((x,i)=>{const val=typeof x==="number"?x:x.pct,b=document.createElement("div");b.className="bar";b.style.height=Math.max(4,val)+"%";b.innerHTML=`<small>${val}%</small>`;ch.appendChild(b)})
}
$("#rescueQuick").onclick=()=>{const c=$("#rescueContent");if(!plan){c.innerHTML="<p>Crea prima un piano di studio.</p>"}else{const days=daysLeft(),pending=plan.schedule.filter(x=>!x.done),study=pending.filter(x=>x.type==="study"),daily=study.length?Math.max(1,Math.ceil(study.length/Math.max(1,days-Math.min(3,days)))):0,weak=[...new Set(errors.map(x=>x.topic).filter(Boolean))].slice(0,3);c.innerHTML=`<div class="rescue-step"><b>Tempo</b><p>${days} giorni · ${pending.length} sessioni aperte</p></div><div class="rescue-step"><b>1. Priorità</b><p>${daily} sessioni di studio al giorno.</p></div><div class="rescue-step"><b>2. Verifica</b><p>Un quiz breve dopo ogni blocco.</p></div><div class="rescue-step"><b>3. Errori</b><p>${weak.length?`Concentrati su ${weak.map(esc).join(", ")}.`:"Ripassa gli errori ogni sera."}</p></div><div class="rescue-step"><b>4. Simulazione</b><p>${days<=7?"Una al giorno.":"Una ogni 2–3 giorni."}</p></div>`}$("#rescueSheet").classList.remove("hidden")};
$("#closeRescue").onclick=()=>$("#rescueSheet").classList.add("hidden");
$("#rescueSheet").onclick=e=>{if(e.target===$("#rescueSheet"))$("#rescueSheet").classList.add("hidden")};

$("#exportBtn").onclick=()=>{const data=JSON.stringify({plan,errors,stats,streak,mastery,focusSessions,weeklyGoal,flashcards,notes,tasks,exams,resources,dailyTarget,journal,oralSessions,savedQuestions,theme:load(K.theme,false)},null,2);prompt("Copia questo backup:",data)};
$("#resetAllBtn").onclick=()=>{if(confirm("Cancellare tutti i dati locali?")){Object.values(K).forEach(k=>localStorage.removeItem(k));plan=null;errors=[];stats=[];streak={days:[],xp:0};mastery={};focusSessions=[];weeklyGoal=300;flashcards=[];notes=[];tasks=[];exams=[];resources=[];dailyTarget=60;render();toast("Dati cancellati.")}};

function render(){renderHome();renderPlan();renderReview();renderStats();renderMastery();renderWeeklyGoal();renderFlashcards();renderDueReview();renderNotes();renderTasks();renderAchievements();renderExams();renderResources();renderDailyScore();renderSmartSuggestion();updateDailyTargetState()}

function bridgeCall(method,...args){
  return new Promise((resolve,reject)=>{
    if(!window.AndroidBridge || typeof window.AndroidBridge[method]!=="function") return reject(new Error("Servizio non disponibile."));
    const cb="cb_"+Date.now()+"_"+Math.random().toString(36).slice(2);
    window.__cbs=window.__cbs||{};
    window.__cbs[cb]=(ok,data)=>{
      try{
        const d=JSON.parse(data);
        if(!ok) reject(new Error(d.error||"Errore di rete"));
        else resolve(d);
      }catch(e){reject(e)}
      delete window.__cbs[cb];
    };
    window.AndroidBridge[method](...args,cb);
  });
}

async function saveCloudState(){
  if(!cloudReady)return;
  updateSyncStatus("Sincronizzo…","online");
  try{await bridgeCall("saveCloud",JSON.stringify(snapshot()));updateSyncStatus("Sincronizzato","online")}catch(e){updateSyncStatus("Offline","offline")}
}
async function loadCloudState(){
  try{
    const r=await bridgeCall("loadCloud");
    const d=r.data||{};
    if(d.state){
      const s=d.state;
      if(Array.isArray(s.studyPlans)){studyPlans=s.studyPlans;localStorage.setItem(K.plans,JSON.stringify(studyPlans));activePlanId=s.activePlanId||studyPlans[0]?.id||null;localStorage.setItem(K.activePlan,JSON.stringify(activePlanId));plan=studyPlans.find(p=>p.id===activePlanId)||studyPlans[0]||null;localStorage.setItem(K.plan,JSON.stringify(plan))}else if("plan" in s){plan=s.plan;if(plan){plan.id=plan.id||`exam-${Date.now()}`;studyPlans=[plan];activePlanId=plan.id;localStorage.setItem(K.plans,JSON.stringify(studyPlans));localStorage.setItem(K.activePlan,JSON.stringify(activePlanId))}localStorage.setItem(K.plan,JSON.stringify(plan))}
      if(Array.isArray(s.errors)){errors=s.errors;localStorage.setItem(K.errors,JSON.stringify(errors))}
      if(Array.isArray(s.stats)){stats=s.stats;localStorage.setItem(K.stats,JSON.stringify(stats))}
      if(s.streak){streak=s.streak;localStorage.setItem(K.streak,JSON.stringify(streak))}
      if(s.mastery&&typeof s.mastery==="object"){mastery=s.mastery;localStorage.setItem(K.mastery,JSON.stringify(mastery))}
      if(typeof s.notif==="boolean")localStorage.setItem(K.notif,JSON.stringify(s.notif))
      if(Array.isArray(s.focusSessions)){focusSessions=s.focusSessions;localStorage.setItem(K.focus,JSON.stringify(focusSessions))}
      if(Number.isFinite(s.weeklyGoal)){weeklyGoal=s.weeklyGoal;localStorage.setItem(K.goal,JSON.stringify(weeklyGoal))}
      if(Array.isArray(s.flashcards)){flashcards=s.flashcards;localStorage.setItem(K.flash,JSON.stringify(flashcards))}
      if(Array.isArray(s.notes)){notes=s.notes;localStorage.setItem(K.notes,JSON.stringify(notes))}
      if(Array.isArray(s.tasks)){tasks=s.tasks;localStorage.setItem(K.tasks,JSON.stringify(tasks))}
      if(Array.isArray(s.exams)){exams=s.exams;localStorage.setItem(K.exams,JSON.stringify(exams))}
      if(Array.isArray(s.resources)){resources=s.resources;localStorage.setItem(K.resources,JSON.stringify(resources))}
      if(Number.isFinite(s.dailyTarget)){dailyTarget=s.dailyTarget;localStorage.setItem(K.dailyTarget,JSON.stringify(dailyTarget))}
      if(typeof s.theme==="boolean")localStorage.setItem(K.theme,JSON.stringify(s.theme));
    }else{
      await bridgeCall("saveCloud",JSON.stringify(snapshot()));
    }
  }catch(e){}
}
function showLogin(){ $("#loginScreen")?.classList.remove("hidden"); }
function hideLogin(){ $("#loginScreen")?.classList.add("hidden"); }
function setProfile(){
  const pe=$("#profileEmail"), lb=$("#logoutBtn");
  if(currentUser){
    pe.textContent=currentUser.email||"Account sincronizzato";
    lb.innerHTML='<span>↪</span><div><b>Esci</b><small>Disconnetti questo account</small></div><i>›</i>';
  }else{
    pe.textContent="Modalità ospite · dati solo su questo dispositivo";
    lb.innerHTML='<span>↪</span><div><b>Accedi e sincronizza</b><small>Salva i progressi anche su altri dispositivi</small></div><i>›</i>';
  }
}

async function initAccount(){
  render();
  applyTheme();
  const guest=localStorage.getItem("ef_guest_mode")==="1";
  try{
    const r=await bridgeCall("authStatus");
    const u=r?.data?.user;
    if(u){
      currentUser=u;localStorage.removeItem("ef_guest_mode");hideLogin();updateSyncStatus("Online","online");
      await loadCloudState();cloudReady=true;setProfile();applyTheme();render();return;
    }
  }catch(e){}
  currentUser=null;cloudReady=false;setProfile();updateSyncStatus(navigator.onLine?"Locale":"Offline",navigator.onLine?null:"offline");
  if(guest)hideLogin();else showLogin();
}

(function setupLogin(){
  let step="email",resendTimer=null,remaining=0;
  const email=$("#loginEmail"),code=$("#loginCode"),codeWrap=$("#codeWrap"),
        btn=$("#loginBtn"),resend=$("#resendBtn"),back=$("#backEmailBtn"),msg=$("#loginMsg");

  function setMsg(t){msg.textContent=t}
  function startCooldown(){
    remaining=30;resend.disabled=true;resend.classList.remove("hidden");
    clearInterval(resendTimer);
    resendTimer=setInterval(()=>{
      remaining--;resend.textContent=remaining>0?`Invia di nuovo (${remaining}s)`:"Invia di nuovo il codice";
      if(remaining<=0){clearInterval(resendTimer);resend.disabled=false}
    },1000);
  }
  async function sendCode(){
    const e=email.value.trim();
    if(!e)return setMsg("Inserisci un indirizzo email.");
    btn.disabled=true;setMsg("Invio del codice in corso...");
    try{
      const r=await bridgeCall("startLogin",e);
      if(!r.ok)throw new Error(r?.data?.message||"Impossibile inviare il codice.");
      step="code";email.disabled=true;codeWrap.classList.remove("hidden");back.classList.remove("hidden");
      btn.textContent="Accedi";setMsg("Codice inviato. Controlla anche Spam e Promozioni.");code.focus();startCooldown();
    }catch(e){setMsg(e.message||"Impossibile inviare il codice.")}
    finally{btn.disabled=false}
  }
  btn.onclick=async()=>{
    if(step==="email")return sendCode();
    const e=email.value.trim(),c=code.value.trim();
    if(c.length!==6)return setMsg("Inserisci il codice a 6 cifre.");
    btn.disabled=true;setMsg("Verifica in corso...");
    try{
      const r=await bridgeCall("verifyCode",e,c);
      if(!r.ok)throw new Error(r?.data?.message||r?.data?.error||"Codice non valido.");
      const s=await bridgeCall("authStatus");
      const u=s?.data?.user;
      if(!u)throw new Error("Accesso non completato.");
      currentUser=u;localStorage.removeItem("ef_guest_mode");hideLogin();updateSyncStatus("Online","online");
      await loadCloudState();cloudReady=true;setProfile();applyTheme();render();toast("Accesso effettuato e sincronizzazione attiva.");
    }catch(e){setMsg(e.message||"Codice non valido.")}
    finally{btn.disabled=false}
  };
  resend.onclick=sendCode;
  back.onclick=()=>{
    step="email";email.disabled=false;codeWrap.classList.add("hidden");back.classList.add("hidden");resend.classList.add("hidden");
    btn.textContent="Invia codice";code.value="";setMsg("Accedendo puoi sincronizzare piano, progressi, errori e statistiche tra più dispositivi.");email.focus();
  };
  const guest=()=>{
    currentUser=null;cloudReady=false;localStorage.setItem("ef_guest_mode","1");hideLogin();setProfile();toast("Modalità ospite attiva.");
  };
  $("#guestBtn").onclick=guest;
  $("#guestClose").onclick=guest;

  $("#logoutBtn").onclick=async()=>{
    if(!currentUser){localStorage.removeItem("ef_guest_mode");showLogin();return}
    try{await bridgeCall("signOut")}catch(e){}
    currentUser=null;cloudReady=false;localStorage.removeItem("ef_guest_mode");setProfile();showLogin();
  };
})();






// Calendario mensile
let calendarCursor=new Date(),calendarSelected=nowDay();
function calendarEvents(dateStr){
  const items=[];
  exams.filter(e=>e.date===dateStr).forEach(e=>items.push({type:"exam",title:e.name,meta:"Esame"}));
  tasks.filter(t=>t.date===dateStr).forEach(t=>items.push({type:"task",title:t.text,meta:t.done?"Completata":"Checklist"}));
  plan?.schedule?.filter(s=>s.date===dateStr).forEach(s=>items.push({type:"study",title:s.type==="study"?`Studio ${s.from}-${s.to}`:"Ripasso",meta:plan.subject||"Piano"}));
  focusSessions.filter(s=>(s.date||"").slice(0,10)===dateStr).forEach(s=>items.push({type:"focus",title:s.topic||"Focus",meta:`${s.minutes||0} min`}));
  return items;
}
function renderCalendar(){
  const grid=$("#calendarGrid"),title=$("#calendarTitle"),details=$("#calendarDayDetails");if(!grid||!title||!details)return;
  const y=calendarCursor.getFullYear(),m=calendarCursor.getMonth();
  title.textContent=new Date(y,m,1).toLocaleDateString("it-IT",{month:"long",year:"numeric"});
  const first=new Date(y,m,1),offset=(first.getDay()+6)%7;
  const start=new Date(y,m,1-offset);
  grid.innerHTML="";
  for(let i=0;i<42;i++){
    const d=new Date(start);d.setDate(start.getDate()+i);
    const ds=localDay(d),events=calendarEvents(ds);
    const b=document.createElement("button");b.className="calendar-day"+(d.getMonth()!==m?" other":"")+(ds===nowDay()?" today":"")+(ds===calendarSelected?" selected":"");
    b.innerHTML=`<div class="calendar-num">${d.getDate()}</div><div class="calendar-dots">${events.slice(0,4).map(e=>`<span class="calendar-dot ${e.type}"></span>`).join("")}</div>`;
    b.onclick=()=>{calendarSelected=ds;renderCalendar()};
    grid.appendChild(b);
  }
  const ev=calendarEvents(calendarSelected);
  details.innerHTML=`<div class="eyebrow">${new Date(calendarSelected+"T00:00:00").toLocaleDateString("it-IT",{weekday:"long",day:"numeric",month:"long"})}</div>`+
    (ev.length?ev.map(e=>`<div class="calendar-detail"><b>${esc(e.title)}</b><small>${esc(e.meta)}</small></div>`).join(""):'<div class="empty-state">Nessuna attività programmata.</div>');
}
$("#calendarQuick")?.addEventListener("click",()=>{calendarCursor=new Date();calendarSelected=nowDay();$("#calendarSheet").classList.remove("hidden");renderCalendar()});
$("#calendarClose")?.addEventListener("click",()=>$("#calendarSheet").classList.add("hidden"));
$("#calendarPrev")?.addEventListener("click",()=>{calendarCursor.setMonth(calendarCursor.getMonth()-1);renderCalendar()});
$("#calendarNext")?.addEventListener("click",()=>{calendarCursor.setMonth(calendarCursor.getMonth()+1);renderCalendar()});
$("#calendarSheet")?.addEventListener("click",e=>{if(e.target===$("#calendarSheet"))$("#calendarSheet").classList.add("hidden")});

// Cronologia
let historyFilter="all";
function historyItems(){
  const out=[];
  focusSessions.forEach(s=>out.push({type:"focus",date:s.date,title:s.topic||"Sessione Focus",value:`${s.minutes||0} min`,icon:"◷"}));
  stats.forEach(s=>out.push({type:"quiz",date:s.date,title:`${s.subject||"Quiz"} · ${s.topic||""}`,value:`${s.pct||0}%`,icon:"✦"}));
  tasks.filter(t=>t.done).forEach(t=>out.push({type:"task",date:(t.date||nowDay())+"T12:00:00",title:t.text,value:"Fatto",icon:"✓"}));
  return out.sort((a,b)=>new Date(b.date)-new Date(a.date));
}
function renderHistory(){
  const el=$("#historyList");if(!el)return;
  const rows=historyItems().filter(x=>historyFilter==="all"||x.type===historyFilter).slice(0,100);
  if(!rows.length){el.innerHTML='<div class="empty-state">Nessuna attività registrata.</div>';return}
  el.innerHTML=rows.map(x=>`<div class="history-item"><div class="history-icon">${x.icon}</div><div><b>${esc(x.title)}</b><small>${new Date(x.date).toLocaleString("it-IT",{day:"numeric",month:"short",hour:"2-digit",minute:"2-digit"})}</small></div><div class="history-value">${esc(x.value)}</div></div>`).join("");
}
$("#historyQuick")?.addEventListener("click",()=>{$("#historySheet").classList.remove("hidden");renderHistory()});
$("#historyClose")?.addEventListener("click",()=>$("#historySheet").classList.add("hidden"));
$("#historySheet")?.addEventListener("click",e=>{if(e.target===$("#historySheet"))$("#historySheet").classList.add("hidden")});
$$(".history-seg").forEach(b=>b.onclick=()=>{$$(".history-seg").forEach(x=>x.classList.remove("active"));b.classList.add("active");historyFilter=b.dataset.history;renderHistory()});

// Obiettivo giornaliero
$("#dailyTargetBtn")?.addEventListener("click",()=>{
  const v=prompt("Quanti minuti vuoi studiare ogni giorno?",String(dailyTarget));
  if(v===null)return;
  const n=parseInt(v,10);
  if(!Number.isFinite(n)||n<10||n>720)return toast("Inserisci un valore tra 10 e 720 minuti.");
  dailyTarget=n;save(K.dailyTarget,dailyTarget);updateDailyTargetState();renderDailyScore();toast("Obiettivo giornaliero aggiornato.");
});

// Esami multipli
$("#examsQuick")?.addEventListener("click",()=>{$("#examsSheet").classList.remove("hidden");renderExams()});
$("#examsClose")?.addEventListener("click",()=>$("#examsSheet").classList.add("hidden"));
$("#examsSheet")?.addEventListener("click",e=>{if(e.target===$("#examsSheet"))$("#examsSheet").classList.add("hidden")});
$("#examAddBtn")?.addEventListener("click",()=>{
  const name=$("#examNameInput").value.trim(),date=$("#examDateInput").value;
  if(!name||!date)return toast("Inserisci nome e data dell'esame.");
  exams.push({id:"e_"+Date.now(),name,date,created:new Date().toISOString()});
  save(K.exams,exams);$("#examNameInput").value="";$("#examDateInput").value="";renderExams();toast("Esame aggiunto.");
});

// Ricerca globale
$("#searchQuick")?.addEventListener("click",()=>{$("#searchSheet").classList.remove("hidden");$("#globalSearchInput").focus();renderSearch("")});
$("#searchClose")?.addEventListener("click",()=>$("#searchSheet").classList.add("hidden"));
$("#searchSheet")?.addEventListener("click",e=>{if(e.target===$("#searchSheet"))$("#searchSheet").classList.add("hidden")});
$("#globalSearchInput")?.addEventListener("input",e=>renderSearch(e.target.value));

// Materiali
$("#resourcesQuick")?.addEventListener("click",()=>{$("#resourcesSheet").classList.remove("hidden");renderResources()});
$("#resourcesClose")?.addEventListener("click",()=>$("#resourcesSheet").classList.add("hidden"));
$("#resourcesSheet")?.addEventListener("click",e=>{if(e.target===$("#resourcesSheet"))$("#resourcesSheet").classList.add("hidden")});
$("#resourceAddBtn")?.addEventListener("click",()=>{
  const title=$("#resourceTitle").value.trim(),url=$("#resourceUrl").value.trim(),note=$("#resourceNote").value.trim();
  if(!title&&!url)return toast("Inserisci almeno un titolo o un link.");
  if(url && !/^https?:\/\//i.test(url))return toast("Il link deve iniziare con http:// o https://");
  resources.unshift({title:title||"Materiale",url,note,date:new Date().toISOString()});
  resources=resources.slice(0,200);save(K.resources,resources);
  $("#resourceTitle").value="";$("#resourceUrl").value="";$("#resourceNote").value="";
  renderResources();toast("Materiale salvato.");
});

// Appunti
const notesQuick=$("#notesQuick");
if(notesQuick)notesQuick.onclick=()=>{$("#notesSheet").classList.remove("hidden");renderNotes()};
$("#notesClose")?.addEventListener("click",()=>$("#notesSheet").classList.add("hidden"));
$("#notesSheet")?.addEventListener("click",e=>{if(e.target===$("#notesSheet"))$("#notesSheet").classList.add("hidden")});
$("#noteSaveBtn")?.addEventListener("click",()=>{
  const title=$("#noteTitle").value.trim(),body=$("#noteBody").value.trim();
  if(!title&&!body)return toast("Scrivi almeno un titolo o un contenuto.");
  notes.unshift({title:title||"Appunto",body,date:new Date().toISOString()});notes=notes.slice(0,300);
  save(K.notes,notes);$("#noteTitle").value="";$("#noteBody").value="";renderNotes();toast("Appunto salvato.");
});

// Checklist giornaliera
const tasksQuick=$("#tasksQuick");
if(tasksQuick)tasksQuick.onclick=()=>{$("#tasksSheet").classList.remove("hidden");renderTasks()};
$("#tasksClose")?.addEventListener("click",()=>$("#tasksSheet").classList.add("hidden"));
$("#tasksSheet")?.addEventListener("click",e=>{if(e.target===$("#tasksSheet"))$("#tasksSheet").classList.add("hidden")});
$("#taskAddBtn")?.addEventListener("click",()=>{
  const text=$("#taskInput").value.trim();if(!text)return toast("Inserisci un'attività.");
  tasks.push({text,done:false,date:nowDay()});save(K.tasks,tasks);$("#taskInput").value="";renderTasks();
});
$("#taskInput")?.addEventListener("keydown",e=>{if(e.key==="Enter")$("#taskAddBtn").click()});

// Ripasso flashcard in scadenza
$("#dueReviewBtn")?.addEventListener("click",()=>{
  $("#flashSheet").classList.remove("hidden");renderFlashcards();
});

// Obiettivo settimanale
const editGoalBtn=$("#editGoalBtn");
if(editGoalBtn)editGoalBtn.onclick=()=>{
  const v=prompt("Quanti minuti vuoi studiare ogni settimana?",String(weeklyGoal));
  if(v===null)return;
  const n=parseInt(v,10);
  if(!Number.isFinite(n)||n<30||n>5000)return toast("Inserisci un valore tra 30 e 5000 minuti.");
  weeklyGoal=n;save(K.goal,weeklyGoal);renderWeeklyGoal();toast("Obiettivo settimanale aggiornato.");
};

// Focus timer
let focusTotal=25*60,focusLeft=focusTotal,focusRunning=false,focusInterval=null;
function paintFocus(){
  const el=$("#focusTimer");if(!el)return;
  const m=Math.floor(focusLeft/60),s=focusLeft%60;el.textContent=`${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`;
  const b=$("#focusStart");if(b)b.textContent=focusRunning?"Pausa":focusLeft<focusTotal?"Riprendi":"Avvia";
}
function setFocusMinutes(min){
  clearInterval(focusInterval);focusRunning=false;focusTotal=min*60;focusLeft=focusTotal;paintFocus();
  $$(".focus-preset").forEach(x=>x.classList.toggle("active",+x.dataset.min===min));
}
function completeFocus(){
  focusRunning=false;clearInterval(focusInterval);focusLeft=0;paintFocus();
  const topic=$("#focusTopic")?.value.trim()||"Studio";
  const minutes=Math.round(focusTotal/60);
  focusSessions.unshift({date:new Date().toISOString(),minutes,topic});
  focusSessions=focusSessions.slice(0,500);save(K.focus,focusSessions);
  streak.xp=(streak.xp||0)+Math.max(5,Math.round(minutes/5));save(K.streak,streak);
  render();toast(`Sessione completata: ${minutes} min registrati.`);
}
const focusQuick=$("#focusQuick");
if(focusQuick)focusQuick.onclick=()=>{$("#focusSheet").classList.remove("hidden");paintFocus()};
const focusClose=$("#focusClose");
if(focusClose)focusClose.onclick=()=>$("#focusSheet").classList.add("hidden");
const focusReset=$("#focusReset");
if(focusReset)focusReset.onclick=()=>setFocusMinutes(Math.round(focusTotal/60));
const focusStart=$("#focusStart");
if(focusStart)focusStart.onclick=()=>{
  if(focusRunning){focusRunning=false;clearInterval(focusInterval);paintFocus();return}
  focusRunning=true;paintFocus();
  focusInterval=setInterval(()=>{focusLeft--;if(focusLeft<=0)completeFocus();else paintFocus()},1000);
};
$$(".focus-preset").forEach(b=>b.onclick=()=>setFocusMinutes(+b.dataset.min));
$("#focusSheet")?.addEventListener("click",e=>{if(e.target===$("#focusSheet"))$("#focusSheet").classList.add("hidden")});

// Flashcard
const flashQuick=$("#flashQuick");
if(flashQuick)flashQuick.onclick=()=>{$("#flashSheet").classList.remove("hidden");renderFlashcards()};
const flashClose=$("#flashClose");
if(flashClose)flashClose.onclick=()=>$("#flashSheet").classList.add("hidden");
$("#flashSheet")?.addEventListener("click",e=>{if(e.target===$("#flashSheet"))$("#flashSheet").classList.add("hidden")});
const flashAddBtn=$("#flashAddBtn");
if(flashAddBtn)flashAddBtn.onclick=()=>{
  const front=$("#flashFront").value.trim(),back=$("#flashBack").value.trim();
  if(!front||!back)return toast("Inserisci domanda e risposta.");
  flashcards.push({front,back,known:0,date:new Date().toISOString()});save(K.flash,flashcards);
  $("#flashFront").value="";$("#flashBack").value="";renderFlashcards();toast("Flashcard aggiunta.");
};

// Import backup
const importBtn=$("#importBtn");
if(importBtn)importBtn.onclick=()=>{
  const raw=prompt("Incolla qui il backup JSON di ExamFlow:");
  if(!raw)return;
  try{
    const d=JSON.parse(raw);
    if("plan" in d)plan=d.plan;
    if(Array.isArray(d.errors))errors=d.errors;
    if(Array.isArray(d.stats))stats=d.stats;
    if(d.streak)streak=d.streak;
    if(d.mastery&&typeof d.mastery==="object")mastery=d.mastery;
    if(Array.isArray(d.focusSessions))focusSessions=d.focusSessions;
    if(Number.isFinite(d.weeklyGoal))weeklyGoal=d.weeklyGoal;
    if(Array.isArray(d.flashcards))flashcards=d.flashcards;
    if(Array.isArray(d.notes))notes=d.notes;
    if(Array.isArray(d.tasks))tasks=d.tasks;
    if(Array.isArray(d.exams))exams=d.exams;
    if(Array.isArray(d.resources))resources=d.resources;
    if(Number.isFinite(d.dailyTarget))dailyTarget=d.dailyTarget;
    if(Array.isArray(d.journal))journal=d.journal;
    if(typeof d.theme==="boolean")localStorage.setItem(K.theme,JSON.stringify(d.theme));
    localStorage.setItem(K.plan,JSON.stringify(plan));localStorage.setItem(K.errors,JSON.stringify(errors));
    localStorage.setItem(K.stats,JSON.stringify(stats));localStorage.setItem(K.streak,JSON.stringify(streak));
    localStorage.setItem(K.mastery,JSON.stringify(mastery));localStorage.setItem(K.focus,JSON.stringify(focusSessions));
    localStorage.setItem(K.goal,JSON.stringify(weeklyGoal));localStorage.setItem(K.flash,JSON.stringify(flashcards));localStorage.setItem(K.notes,JSON.stringify(notes));localStorage.setItem(K.tasks,JSON.stringify(tasks));localStorage.setItem(K.exams,JSON.stringify(exams));localStorage.setItem(K.resources,JSON.stringify(resources));localStorage.setItem(K.dailyTarget,JSON.stringify(dailyTarget));localStorage.setItem(K.journal,JSON.stringify(journal));
    if(cloudReady){clearTimeout(cloudTimer);cloudTimer=setTimeout(saveCloudState,700)}applyTheme();render();toast("Backup importato.");
  }catch(e){toast("Backup non valido.");}
};

function updateNotifState(){
  const enabled=load(K.notif,false),el=$("#notifState");if(el)el.textContent=enabled?"Attivi":"Disattivati";
}
const notifBtn=$("#notifBtn");
if(notifBtn)notifBtn.onclick=()=>{
  const next=!load(K.notif,false);save(K.notif,next);updateNotifState();
  try{if(window.AndroidBridge&&window.AndroidBridge.setStudyReminders)window.AndroidBridge.setStudyReminders(next)}catch(e){}
  toast(next?"Promemoria studio attivati.":"Promemoria studio disattivati.");
};
updateNotifState();

window.addEventListener("online",()=>{updateSyncStatus(currentUser?"Online":"Locale",currentUser?"online":null);if(currentUser&&cloudReady)saveCloudState()});
window.addEventListener("offline",()=>updateSyncStatus("Offline","offline"));

const moreToolsQuick=$("#moreToolsQuick");
if(moreToolsQuick)moreToolsQuick.onclick=()=>$("#moreToolsSheet").classList.remove("hidden");
$("#moreToolsClose")?.addEventListener("click",()=>$("#moreToolsSheet").classList.add("hidden"));
$("#moreToolsSheet")?.addEventListener("click",e=>{if(e.target===$("#moreToolsSheet"))$("#moreToolsSheet").classList.add("hidden")});
["notesQuick","tasksQuick","examsQuick","calendarQuick","searchQuick","resourcesQuick","journalQuick","sessionQuick","forecastQuick","errorFlashQuick","missionQuick","oralQuick","weeklyQuick","examDayQuick","heatmapQuick","historyQuick"].forEach(id=>{
  $("#"+id)?.addEventListener("click",()=>$("#moreToolsSheet").classList.add("hidden"));
});


// Diario di studio
function renderJournal(){
  const el=$("#journalList");if(!el)return;el.innerHTML="";
  journal.slice().reverse().slice(0,20).forEach((j,ri)=>{const idx=journal.length-1-ri,c=document.createElement("div");c.className="note-item";c.innerHTML=`<div><b>${esc(j.topic)}</b><small>${new Date(j.date).toLocaleDateString("it-IT")} · concentrazione ${j.focus}/5</small><p>${esc(j.note||"")}</p></div><button data-del="${idx}">×</button>`;c.querySelector("button").onclick=()=>{journal.splice(idx,1);save(K.journal,journal);renderJournal()};el.appendChild(c)});
  if(!journal.length)el.innerHTML='<p class="muted tiny">Le tue riflessioni appariranno qui.</p>';
}
$("#journalQuick")?.addEventListener("click",()=>{$("#journalSheet").classList.remove("hidden");renderJournal()});
$("#journalClose")?.addEventListener("click",()=>$("#journalSheet").classList.add("hidden"));
$("#journalSheet")?.addEventListener("click",e=>{if(e.target===$("#journalSheet"))$("#journalSheet").classList.add("hidden")});
$("#journalSaveBtn")?.addEventListener("click",()=>{const topic=$("#journalTopic").value.trim(),note=$("#journalNote").value.trim(),focus=+$("#journalFocus").value;if(!topic)return toast("Inserisci cosa hai studiato.");journal.push({topic,note,focus,date:new Date().toISOString()});save(K.journal,journal);$("#journalTopic").value="";$("#journalNote").value="";renderJournal();toast("Riflessione salvata.")});

// Sessione smart: usa piano, errori e mastery per suggerire una sessione concreta
let smartSessionMinutes=25,smartSessionSteps=[];
function buildSmartSession(mins=smartSessionMinutes){
  smartSessionMinutes=mins;const weak=weakestTopic(),today=localDay(),scheduled=plan?.schedule?.find(x=>x.date===today&&!x.done),topic=weak||scheduled?.topics?.[0]||plan?.subject||"argomento prioritario";
  const review=Math.max(5,Math.round(mins*.2)),study=Math.max(10,Math.round(mins*.55)),test=Math.max(5,mins-review-study);
  smartSessionSteps=[`Ripasso attivo: ${topic} (${review} min)`,`Studio concentrato: ${topic} (${study} min)`,`Verifica senza appunti / quiz (${test} min)`];
  const el=$("#sessionPlan");if(el)el.innerHTML=smartSessionSteps.map((x,i)=>`<div class="session-step"><span>${i+1}</span><div><b>${esc(x)}</b><small>${i===0?"Richiama ciò che sai prima di rileggere.":i===1?"Concentrati sui passaggi che ricordi peggio.":"Chiudi con una verifica e salva gli errori."}</small></div></div>`).join("");
}
$("#sessionQuick")?.addEventListener("click",()=>{$("#sessionSheet").classList.remove("hidden");buildSmartSession()});
$("#sessionClose")?.addEventListener("click",()=>$("#sessionSheet").classList.add("hidden"));
$("#sessionSheet")?.addEventListener("click",e=>{if(e.target===$("#sessionSheet"))$("#sessionSheet").classList.add("hidden")});
$$(".session-len").forEach(b=>b.addEventListener("click",()=>{$$(".session-len").forEach(x=>x.classList.remove("active"));b.classList.add("active");buildSmartSession(+b.dataset.min)}));
$("#sessionToTasks")?.addEventListener("click",()=>{if(!smartSessionSteps.length)buildSmartSession();smartSessionSteps.forEach(text=>tasks.push({text,done:false,date:localDay(),createdAt:new Date().toISOString()}));save(K.tasks,tasks);renderTasks();toast("Sessione aggiunta alla checklist.")});


// Previsione esame: combina quiz, avanzamento, mastery e costanza
function examForecast(){
  const recent=stats.slice(0,12),quiz=recent.length?recent.reduce((a,b)=>a+b.pct,0)/recent.length:0,progress=progressPct();
  const vals=Object.values(mastery||{}).map(x=>typeof x==="number"?x:(x?.pct||x?.score||0));
  const mast=vals.length?vals.reduce((a,b)=>a+b,0)/vals.length:quiz;
  const consistency=Math.min(100,streakCount()*12+(focusSessions.filter(x=>Date.now()-new Date(x.date).getTime()<7*86400000).length*8));
  const ready=Math.round(quiz*.42+progress*.28+mast*.18+consistency*.12);
  const grade=Math.max(18,Math.min(30,Math.round(18+ready*12/100)));
  return {ready,grade,quiz:Math.round(quiz),progress,mast:Math.round(mast),consistency};
}
function renderForecast(){const f=examForecast(),el=$("#forecastContent");if(!el)return;el.innerHTML=`<div class="forecast-score"><b>${f.ready}%</b><span>preparazione stimata</span></div><div class="forecast-grade">Voto indicativo <strong>${f.grade}/30</strong></div><div class="forecast-grid"><div><b>${f.quiz}%</b><small>Quiz</small></div><div><b>${f.progress}%</b><small>Piano</small></div><div><b>${f.mast}%</b><small>Padronanza</small></div><div><b>${f.consistency}%</b><small>Costanza</small></div></div><p>${f.ready>=80?"Preparazione solida: consolida gli errori e fai simulazioni complete.":f.ready>=60?"Buona base: concentra il lavoro sugli argomenti più deboli.":"Servono ancora consolidamento e verifiche frequenti."}</p>`}
$("#forecastQuick")?.addEventListener("click",()=>{$("#forecastSheet").classList.remove("hidden");renderForecast()});
$("#forecastClose")?.addEventListener("click",()=>$("#forecastSheet").classList.add("hidden"));
$("#forecastSheet")?.addEventListener("click",e=>{if(e.target===$("#forecastSheet"))$("#forecastSheet").classList.add("hidden")});

// Trasforma automaticamente gli errori aperti in flashcard, evitando duplicati
$("#errorFlashQuick")?.addEventListener("click",()=>{if(!errors.length)return toast("Non hai errori aperti da trasformare.");let n=0;errors.slice(0,20).forEach(e=>{if(!flashcards.some(f=>f.front===e.q)){flashcards.push({front:e.q,back:`${e.a}${e.explanation?" — "+e.explanation:""}`,known:0,stage:0,due:localDay(),date:new Date().toISOString(),source:"error"});n++}});save(K.flash,flashcards);renderFlashcards();renderDueReview();toast(n?`${n} flashcard create dagli errori.`:"Gli errori sono già presenti nelle flashcard.")});

// Missione giornaliera adattiva
let dailyMission=[];
function buildDailyMission(){const weak=weakestTopic()||plan?.subject||"materia principale",due=dueFlashcards().length,days=daysLeft();dailyMission=[`25 min di focus su ${weak}`,due?`Ripassa ${Math.min(10,due)} flashcard in scadenza`:`Crea 3 flashcard su ${weak}`,`Completa un quiz di 5 domande su ${weak}`,errors.length?`Rivedi ${Math.min(3,errors.length)} errori aperti`:(days<=7?"Fai una mini simulazione d'esame":"Richiamo attivo senza appunti per 10 minuti")];const el=$("#missionContent");if(el)el.innerHTML=dailyMission.map((x,i)=>`<div class="session-step"><span>${i+1}</span><div><b>${esc(x)}</b><small>${i===dailyMission.length-1?"Chiudi la missione verificando cosa ricordi.":"Completa il passaggio e continua."}</small></div></div>`).join("")}
$("#missionQuick")?.addEventListener("click",()=>{$("#missionSheet").classList.remove("hidden");buildDailyMission()});
$("#missionClose")?.addEventListener("click",()=>$("#missionSheet").classList.add("hidden"));
$("#missionSheet")?.addEventListener("click",e=>{if(e.target===$("#missionSheet"))$("#missionSheet").classList.add("hidden")});
$("#missionToTasks")?.addEventListener("click",()=>{if(!dailyMission.length)buildDailyMission();dailyMission.forEach(text=>tasks.push({text,done:false,date:localDay(),createdAt:new Date().toISOString(),source:"mission"}));save(K.tasks,tasks);renderTasks();toast("Missione aggiunta alla checklist.")});


// Interrogazione orale: usa contenuti già presenti, senza chiamate AI aggiuntive
let oralCurrent=null;
function oralPool(){const out=[];errors.forEach(e=>out.push({q:e.q,a:`${e.a}${e.explanation?" — "+e.explanation:""}`,topic:e.topic||e.subject||"Errore"}));flashcards.forEach(f=>out.push({q:f.front,a:f.back,topic:"Flashcard"}));return out}
function nextOral(){const pool=oralPool(),q=$("#oralQuestion"),a=$("#oralAnswer");if(!pool.length){q.innerHTML='<p class="muted">Aggiungi flashcard o completa qualche quiz per creare domande orali.</p>';oralCurrent=null;return}oralCurrent=pool[Math.floor(Math.random()*pool.length)];q.innerHTML=`<small>${esc(oralCurrent.topic)}</small><b>${esc(oralCurrent.q)}</b><p>Rispondi ad alta voce prima di mostrare la soluzione.</p>`;a.textContent=oralCurrent.a;a.classList.add("hidden")}
$("#oralQuick")?.addEventListener("click",()=>{$("#oralSheet").classList.remove("hidden");nextOral()});
$("#oralReveal")?.addEventListener("click",()=>$("#oralAnswer").classList.remove("hidden"));
$("#oralNext")?.addEventListener("click",nextOral);$("#oralClose")?.addEventListener("click",()=>$("#oralSheet").classList.add("hidden"));
$$('.oral-rating button').forEach(b=>b.addEventListener('click',()=>{if(!oralCurrent)return;oralSessions.push({topic:oralCurrent.topic,question:oralCurrent.q,rating:+b.dataset.rate,date:new Date().toISOString()});oralSessions=oralSessions.slice(-200);save(K.oral,oralSessions);toast(b.dataset.rate==='3'?"Risposta consolidata.":"Segnata per ulteriore ripasso.");nextOral()}));

// Report settimanale con dati reali dell'utente
function renderWeekly(){const since=Date.now()-7*86400000,qs=stats.filter(x=>new Date(x.date).getTime()>=since),fs=focusSessions.filter(x=>new Date(x.date).getTime()>=since),js=journal.filter(x=>new Date(x.date).getTime()>=since),os=oralSessions.filter(x=>new Date(x.date).getTime()>=since),avg=qs.length?Math.round(qs.reduce((a,b)=>a+b.pct,0)/qs.length):0,mins=fs.reduce((a,b)=>a+(+b.minutes||+b.duration||0),0),weak=weakestTopic()||"Completa altri quiz";$("#weeklyContent").innerHTML=`<div class="forecast-grid"><div><b>${qs.length}</b><small>Quiz</small></div><div><b>${avg}%</b><small>Media</small></div><div><b>${mins}</b><small>Min focus</small></div><div><b>${os.length}</b><small>Orali</small></div></div><div class="weekly-advice"><b>Priorità prossima settimana</b><p>${esc(weak)}</p><small>${js.length?`Hai registrato ${js.length} riflessioni nel diario.`:"Aggiungi una riflessione al diario per capire meglio come studi."}</small></div>`}
$("#weeklyQuick")?.addEventListener("click",()=>{$("#weeklySheet").classList.remove("hidden");renderWeekly()});$("#weeklyClose")?.addEventListener("click",()=>$("#weeklySheet").classList.add("hidden"));

// Strategia automatica per le ultime 24 ore
let examDaySteps=[];function renderExamDay(){const weak=weakestTopic()||plan?.subject||"argomenti chiave",due=dueFlashcards().length;examDaySteps=[`Ripasso leggero degli argomenti chiave: ${weak}`,due?`Ripassa solo ${Math.min(due,15)} flashcard in scadenza`:`Richiamo attivo dei concetti essenziali`,`Rivedi al massimo ${Math.min(errors.length,5)} errori ad alta priorità`,`Prepara materiale, documenti e percorso per l'esame`,`Chiudi lo studio con anticipo e proteggi il sonno`];$("#examDayContent").innerHTML=examDaySteps.map((x,i)=>`<div class="session-step"><span>${i+1}</span><div><b>${esc(x)}</b><small>${i<3?"Niente nuovi capitoli: consolida ciò che sai.":"Riduci lo stress operativo prima dell'esame."}</small></div></div>`).join("")}
$("#examDayQuick")?.addEventListener("click",()=>{$("#examDaySheet").classList.remove("hidden");renderExamDay()});$("#examDayClose")?.addEventListener("click",()=>$("#examDaySheet").classList.add("hidden"));$("#examDayTasks")?.addEventListener("click",()=>{examDaySteps.forEach(text=>tasks.push({text,done:false,date:localDay(),createdAt:new Date().toISOString(),source:"exam-day"}));save(K.tasks,tasks);renderTasks();toast("Piano ultime 24 ore aggiunto alla checklist.")});

// Heatmap attività degli ultimi 30 giorni
function renderHeatmap(){const el=$("#heatmapContent");el.innerHTML="";for(let i=29;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);const key=localDay(d),q=stats.filter(x=>x.date?.slice(0,10)===key).length,f=focusSessions.filter(x=>x.date?.slice(0,10)===key).length,j=journal.filter(x=>x.date?.slice(0,10)===key).length,t=tasks.filter(x=>x.date===key&&x.done).length,score=Math.min(4,q+f+j+t),c=document.createElement("div");c.className=`heat-cell level-${score}`;c.title=`${d.toLocaleDateString("it-IT")}: ${score} attività`;c.innerHTML=`<small>${d.getDate()}</small>`;el.appendChild(c)}}
$("#heatmapQuick")?.addEventListener("click",()=>{$("#heatmapSheet").classList.remove("hidden");renderHeatmap()});$("#heatmapClose")?.addEventListener("click",()=>$("#heatmapSheet").classList.add("hidden"));

initAccount();


// Domande salvate
function savedKey(q){return `${q.question}::${(q.options||[]).join("|")}`}
function toggleSavedQuestion(q,meta,btn){const key=savedKey(q),i=savedQuestions.findIndex(x=>x.key===key);if(i>=0){savedQuestions.splice(i,1);btn.textContent="☆";toast("Domanda rimossa dai salvati.")}else{savedQuestions.unshift({key,question:q.question,options:q.options,correctIndex:q.correctIndex,explanation:q.explanation||"",subject:meta?.subject||"",topic:meta?.topic||"",date:new Date().toISOString()});savedQuestions=savedQuestions.slice(0,150);btn.textContent="★";toast("Domanda salvata.")}save(K.saved,savedQuestions)}
function renderSaved(){const el=$("#savedList");if(!el)return;el.innerHTML=savedQuestions.length?savedQuestions.map((q,i)=>`<div class="saved-item"><div><b>${esc(q.question)}</b><small>${esc(q.subject||"")} · ${esc(q.topic||"")}</small></div><button data-saved-remove="${i}">×</button></div>`).join(""):'<p class="muted">Non hai ancora salvato domande. Tocca ☆ durante un quiz.</p>';$$('[data-saved-remove]').forEach(b=>b.onclick=()=>{savedQuestions.splice(+b.dataset.savedRemove,1);save(K.saved,savedQuestions);renderSaved()})}
$("#savedQuick")?.addEventListener("click",()=>{$("#savedSheet").classList.remove("hidden");renderSaved()});$("#savedClose")?.addEventListener("click",()=>$("#savedSheet").classList.add("hidden"));

// Sprint errori: mini-sessione immediata sui 5 errori più recenti
function renderErrorSprint(){const el=$("#errorSprintContent"),pool=errors.slice(0,5);if(!pool.length){el.innerHTML='<p class="muted">Nessun errore aperto: completa un quiz per alimentare lo sprint.</p>';return}el.innerHTML=pool.map((e,i)=>`<div class="session-step"><span>${i+1}</span><div><b>${esc(e.q)}</b><small>${esc(e.topic||e.subject||"Ripasso")}</small><details><summary>Mostra risposta</summary><p>${esc(e.a)}${e.explanation?" — "+esc(e.explanation):""}</p></details></div></div>`).join("")}
$("#errorSprintQuick")?.addEventListener("click",()=>{$("#errorSprintSheet").classList.remove("hidden");renderErrorSprint()});$("#errorSprintClose")?.addEventListener("click",()=>$("#errorSprintSheet").classList.add("hidden"));

// Trend quiz: confronta gli ultimi 5 risultati con i 5 precedenti
function renderTrend(){const el=$("#trendContent"),a=stats.slice(0,5),b=stats.slice(5,10),avg=x=>x.length?Math.round(x.reduce((s,v)=>s+(+v.pct||0),0)/x.length):0,now=avg(a),prev=avg(b),delta=now-prev;el.innerHTML=`<div class="trend-hero"><b>${now}%</b><span>media ultimi ${a.length} quiz</span></div><div class="trend-delta ${delta>=0?'up':'down'}">${b.length?(delta>=0?'+':'')+delta+' punti rispetto ai precedenti':'Servono almeno 6 quiz per un confronto completo'}</div><div class="trend-bars">${a.slice().reverse().map(x=>`<div><span style="height:${Math.max(5,x.pct)}%"></span><small>${x.pct}%</small></div>`).join('')}</div>`}
$("#trendQuick")?.addEventListener("click",()=>{$("#trendSheet").classList.remove("hidden");renderTrend()});$("#trendClose")?.addEventListener("click",()=>$("#trendSheet").classList.add("hidden"));

// Bilanciamento studio: segnala se si sta usando un solo metodo
function renderBalance(){const since=Date.now()-7*86400000,q=stats.filter(x=>new Date(x.date).getTime()>=since).length,f=focusSessions.filter(x=>new Date(x.date).getTime()>=since).length,o=oralSessions.filter(x=>new Date(x.date).getTime()>=since).length,fl=flashcards.filter(x=>x.lastReview&&new Date(x.lastReview).getTime()>=since).length,vals=[['Quiz',q],['Focus',f],['Orale',o],['Flashcard',fl]],max=Math.max(1,...vals.map(x=>x[1])),missing=vals.filter(x=>x[1]===0).map(x=>x[0]);$("#balanceContent").innerHTML=`<div class="balance-list">${vals.map(([n,v])=>`<div><label>${n}<b>${v}</b></label><span><i style="width:${Math.round(v/max*100)}%"></i></span></div>`).join('')}</div><div class="weekly-advice"><b>Suggerimento</b><p>${missing.length?'Aggiungi '+missing.slice(0,2).join(' e '):'Buon equilibrio tra metodi'}</p><small>Il mix di richiamo attivo, pratica e studio concentrato evita di affidarti a un solo metodo.</small></div>`}
$("#balanceQuick")?.addEventListener("click",()=>{$("#balanceSheet").classList.remove("hidden");renderBalance()});$("#balanceClose")?.addEventListener("click",()=>$("#balanceSheet").classList.add("hidden"));


// Piano intensivo per gli ultimi 7 giorni
let sevenDaySteps=[];
function buildSevenDayPlan(){
  const weak=weakestTopic()||plan?.subject||"argomenti più deboli", openErr=errors.length, due=dueFlashcards().length;
  sevenDaySteps=[
    `Giorno 1 · Diagnosi: quiz misto e revisione di ${Math.min(openErr,10)} errori`,
    `Giorno 2 · Recupero: studio concentrato su ${weak}`,
    `Giorno 3 · Richiamo attivo: ${due?Math.min(due,20)+" flashcard in scadenza":"crea e ripassa flashcard essenziali"}`,
    `Giorno 4 · Simulazione: prova a tempo senza consultare appunti`,
    `Giorno 5 · Correzione: lavora solo sugli errori della simulazione`,
    `Giorno 6 · Seconda simulazione + ripasso leggero dei punti fragili`,
    `Giorno 7 · Richiamo essenziale, organizzazione pratica e stop anticipato`
  ];
  $("#sevenDayContent").innerHTML=sevenDaySteps.map((x,i)=>`<div class="session-step"><span>${i+1}</span><div><b>${esc(x)}</b><small>${i<5?"Consolida prima di aggiungere nuovo materiale.":"Riduci progressivamente il carico."}</small></div></div>`).join("");
}
$("#sevenDayQuick")?.addEventListener("click",()=>{$("#sevenDaySheet").classList.remove("hidden");buildSevenDayPlan()});
$("#sevenDayClose")?.addEventListener("click",()=>$("#sevenDaySheet").classList.add("hidden"));
$("#sevenDayTasks")?.addEventListener("click",()=>{if(!sevenDaySteps.length)buildSevenDayPlan();sevenDaySteps.forEach((text,i)=>tasks.push({text,done:false,date:localDay(addDays(new Date(),i)),createdAt:new Date().toISOString(),source:"7-day"}));save(K.tasks,tasks);renderTasks();toast("Piano di 7 giorni aggiunto alla checklist.")});

// Calibrazione metacognitiva: confronta sicurezza dichiarata e risultati reali
function renderConfidence(){
  const recent=stats.slice(0,10), avg=recent.length?Math.round(recent.reduce((s,x)=>s+(+x.pct||0),0)/recent.length):0;
  const last=confidenceLogs.slice(-8), conf=last.length?Math.round(last.reduce((s,x)=>s+x.value,0)/last.length):null;
  const gap=conf==null?null:conf-avg;
  let verdict=conf==null?"Valuta ora quanto ti senti preparato.":Math.abs(gap)<=10?"La tua percezione è ben calibrata.":gap>10?"Potresti sovrastimare la preparazione: usa una simulazione per verificarti.":"I risultati sono migliori di quanto percepisci: la tua sicurezza potrebbe essere troppo bassa.";
  $("#confidenceContent").innerHTML=`<div class="forecast-grid"><div><b>${avg}%</b><small>Risultati reali</small></div><div><b>${conf==null?'—':conf+'%'}</b><small>Sicurezza percepita</small></div></div><div class="confidence-scale"><p>Quanto ti senti pronto adesso?</p><input id="confidenceRange" type="range" min="0" max="100" step="5" value="${conf??50}"><b id="confidenceValue">${conf??50}%</b><button id="confidenceSave" class="primary-btn full">Registra percezione</button></div><div class="weekly-advice"><b>Lettura</b><p>${esc(verdict)}</p></div>`;
  const r=$("#confidenceRange"),v=$("#confidenceValue");r.oninput=()=>v.textContent=r.value+"%";$("#confidenceSave").onclick=()=>{confidenceLogs.push({value:+r.value,date:new Date().toISOString(),quizAvg:avg});confidenceLogs=confidenceLogs.slice(-100);save(K.confidence,confidenceLogs);toast("Percezione registrata.");renderConfidence()};
}
$("#confidenceQuick")?.addEventListener("click",()=>{$("#confidenceSheet").classList.remove("hidden");renderConfidence()});$("#confidenceClose")?.addEventListener("click",()=>$("#confidenceSheet").classList.add("hidden"));

// Laboratorio errori: causa dell'errore per migliorare il metodo, non solo la risposta
function renderMistakeLab(){
  const el=$("#mistakeLabContent"),pool=errors.slice(0,8);
  if(!pool.length){el.innerHTML='<p class="muted">Non ci sono errori aperti da classificare.</p>';return}
  el.innerHTML=pool.map((e,i)=>{const key=encodeURIComponent((e.q||"").slice(0,120)),tag=mistakeTags[key]||"";return `<div class="mistake-card"><b>${esc(e.q)}</b><small>${esc(e.topic||e.subject||"Quiz")}</small><select data-mistake-key="${key}"><option value="">Perché ho sbagliato?</option><option ${tag==='lacuna'?'selected':''} value="lacuna">Lacuna di conoscenza</option><option ${tag==='confusione'?'selected':''} value="confusione">Confusione tra concetti</option><option ${tag==='distrazione'?'selected':''} value="distrazione">Distrazione / lettura</option><option ${tag==='memoria'?'selected':''} value="memoria">Non ricordavo</option><option ${tag==='tempo'?'selected':''} value="tempo">Pressione del tempo</option></select></div>`}).join("");
  $$('[data-mistake-key]').forEach(s=>s.onchange=()=>{mistakeTags[s.dataset.mistakeKey]=s.value;save(K.mistakeTags,mistakeTags);toast("Causa dell’errore salvata.")});
}
$("#mistakeLabQuick")?.addEventListener("click",()=>{$("#mistakeLabSheet").classList.remove("hidden");renderMistakeLab()});$("#mistakeLabClose")?.addEventListener("click",()=>$("#mistakeLabSheet").classList.add("hidden"));

// Sfida casuale: micro-missione per ridurre l'attrito nel decidere cosa fare
function buildRandomChallenge(){
 const weak=weakestTopic()||plan?.subject||"un argomento dell'esame", pool=[
  `Rispondi senza appunti a 5 domande su ${weak}`,
  `Ripassa 8 flashcard e separa quelle ancora incerte`,
  `Spiega ad alta voce ${weak} come se lo insegnassi a qualcuno`,
  `Rivedi 3 errori recenti e scrivi perché avevi scelto la risposta sbagliata`,
  `Fai 10 minuti di focus senza notifiche su ${weak}`,
  `Scrivi da memoria 5 concetti chiave e poi controlla gli appunti`
 ];
 const pick=pool[Math.floor(Math.random()*pool.length)];$("#randomContent").innerHTML=`<div class="random-challenge"><span>10:00</span><b>${esc(pick)}</b><small>Niente perfezionismo: l'obiettivo è iniziare subito.</small></div>`;
}
$("#randomQuick")?.addEventListener("click",()=>{$("#randomSheet").classList.remove("hidden");buildRandomChallenge()});$("#randomAgain")?.addEventListener("click",buildRandomChallenge);$("#randomClose")?.addEventListener("click",()=>$("#randomSheet").classList.add("hidden"));

// Bottom-sheet drag-to-close fix: trascina verso il basso dalla maniglia.
(function enableSheetDragToClose(){
  document.querySelectorAll('.sheet-backdrop').forEach(backdrop=>{
    const sheet=backdrop.querySelector('.sheet');
    const handle=sheet?.querySelector('.sheet-handle');
    if(!sheet || !handle) return;

    let startY=0, lastY=0, startTime=0, dragging=false;
    handle.style.touchAction='none';

    const reset=()=>{
      dragging=false;
      sheet.style.transition='transform .20s ease';
      sheet.style.transform='translateY(0)';
      setTimeout(()=>{ sheet.style.transition=''; sheet.style.transform=''; },220);
    };
    const close=()=>{
      dragging=false;
      sheet.style.transition='transform .18s ease';
      sheet.style.transform='translateY(105%)';
      setTimeout(()=>{
        backdrop.classList.add('hidden');
        sheet.style.transition='';
        sheet.style.transform='';
      },180);
    };
    handle.addEventListener('pointerdown',e=>{
      if(backdrop.classList.contains('hidden')) return;
      dragging=true; startY=lastY=e.clientY; startTime=Date.now();
      sheet.style.transition='none';
      try{ handle.setPointerCapture(e.pointerId); }catch(_){}
      e.preventDefault();
    });
    handle.addEventListener('pointermove',e=>{
      if(!dragging) return;
      lastY=e.clientY;
      const dy=Math.max(0,lastY-startY);
      sheet.style.transform=`translateY(${dy}px)`;
      e.preventDefault();
    });
    const finish=e=>{
      if(!dragging) return;
      const dy=Math.max(0,lastY-startY), dt=Math.max(1,Date.now()-startTime);
      const velocity=dy/dt;
      (dy>80 || velocity>.55) ? close() : reset();
      try{ handle.releasePointerCapture(e.pointerId); }catch(_){}
    };
    handle.addEventListener('pointerup',finish);
    handle.addEventListener('pointercancel',reset);
  });
})();
